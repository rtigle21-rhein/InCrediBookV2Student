package com.example.incredibookv2;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BookManagementFragment extends Fragment {

    private RecyclerView recyclerViewBooks;
    private BookAdapter bookAdapter;
    private List<Book> bookList;
    private List<Book> filteredBookList;
    private FloatingActionButton fabAddBook;
    private Button btnBackToDashboard;
    private EditText editTextSearch;
    private Spinner spinnerCategoryFilter;

    // Supabase service instead of SQLite
    private SupabaseBookService supabaseBookService;

    private static final int PICK_IMAGE_REQUEST = 1;
    private String selectedCoverImageBase64 = "";

    public BookManagementFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_book_management, container, false);

        initializeViews(view);
        setupRecyclerView();
        loadBooks();
        setupListeners();

        return view;
    }

    private void initializeViews(View view) {
        recyclerViewBooks = view.findViewById(R.id.recyclerViewBooks);
        fabAddBook = view.findViewById(R.id.fabAddBook);
        btnBackToDashboard = view.findViewById(R.id.btnBackToDashboard);
        editTextSearch = view.findViewById(R.id.editTextSearch);
        spinnerCategoryFilter = view.findViewById(R.id.spinnerCategoryFilter);

        bookList = new ArrayList<>();
        filteredBookList = new ArrayList<>();

        // Initialize Supabase service instead of SQLite
        supabaseBookService = new SupabaseBookService(requireContext());

        // Setup category filter spinner
        setupCategorySpinner();
    }

    private void setupCategorySpinner() {
        List<String> categories = new ArrayList<>(Arrays.asList(
                "All Categories", "Fiction", "Non-Fiction", "Science", "Technology",
                "History", "Biography", "Children", "Romance", "Mystery",
                "Fantasy", "Science Fiction", "Horror", "Self-Help", "Business"
        ));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_item,
                categories
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategoryFilter.setAdapter(adapter);
    }

    private void setupRecyclerView() {
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 2);
        recyclerViewBooks.setLayoutManager(layoutManager);

        bookAdapter = new BookAdapter(filteredBookList, new BookAdapter.OnBookClickListener() {
            @Override
            public void onBookClick(Book book) {
                showBookDetailsDialog(book);
            }

            @Override
            public void onBookLongClick(Book book) {
                showBookActionsDialog(book);
            }
        });

        recyclerViewBooks.setAdapter(bookAdapter);
    }

    private void setupListeners() {
        fabAddBook.setOnClickListener(v -> showAddEditBookDialog(null));

        btnBackToDashboard.setOnClickListener(v -> {
            if (getActivity() != null) {
                getActivity().onBackPressed();
            }
        });

        editTextSearch.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterBooks();
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });

        spinnerCategoryFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                filterBooks();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    private void loadBooks() {
        // Show loading state
        Toast.makeText(requireContext(), "Loading books...", Toast.LENGTH_SHORT).show();

        supabaseBookService.getAllBooks(new SupabaseBookService.BooksFetchCallback() {
            @Override
            public void onSuccess(List<Book> books) {
                requireActivity().runOnUiThread(() -> {
                    bookList.clear();
                    bookList.addAll(books);
                    filteredBookList.clear();
                    filteredBookList.addAll(bookList);
                    bookAdapter.notifyDataSetChanged();

                    if (bookList.isEmpty()) {
                        Toast.makeText(requireContext(), "No books found. Add your first book!", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(requireContext(), "Loaded " + books.size() + " books", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> {
                    Log.e("BookManagement", "Error loading books: " + error);
                    Toast.makeText(requireContext(), "Failed to load books: " + error, Toast.LENGTH_LONG).show();

                    // Fallback: show empty state
                    bookList.clear();
                    filteredBookList.clear();
                    bookAdapter.notifyDataSetChanged();
                });
            }
        });
    }

    private void filterBooks() {
        String searchQuery = editTextSearch.getText().toString().toLowerCase().trim();
        String selectedCategory = spinnerCategoryFilter.getSelectedItem().toString();

        filteredBookList.clear();

        for (Book book : bookList) {
            boolean matchesSearch = searchQuery.isEmpty() ||
                    book.getTitle().toLowerCase().contains(searchQuery) ||
                    book.getAuthor().toLowerCase().contains(searchQuery) ||
                    (book.getIsbn() != null && book.getIsbn().toLowerCase().contains(searchQuery));

            boolean matchesCategory = selectedCategory.equals("All Categories") ||
                    (book.getCategory() != null && selectedCategory.equals(book.getCategory()));

            if (matchesSearch && matchesCategory) {
                filteredBookList.add(book);
            }
        }

        bookAdapter.notifyDataSetChanged();

        // Show message if no results
        if (filteredBookList.isEmpty() && (!searchQuery.isEmpty() || !selectedCategory.equals("All Categories"))) {
            Toast.makeText(requireContext(), "No books match your search criteria", Toast.LENGTH_SHORT).show();
        }
    }

    private void showAddEditBookDialog(Book book) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle(book == null ? "Add New Book" : "Edit Book");

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_edit_book, null);
        builder.setView(dialogView);

        // Initialize dialog views
        TextInputLayout tilTitle = dialogView.findViewById(R.id.tilTitle);
        TextInputLayout tilAuthor = dialogView.findViewById(R.id.tilAuthor);
        TextInputLayout tilIsbn = dialogView.findViewById(R.id.tilIsbn);
        TextInputLayout tilCategory = dialogView.findViewById(R.id.tilCategory);
        TextInputLayout tilDescription = dialogView.findViewById(R.id.tilDescription);
        TextInputLayout tilTotalCopies = dialogView.findViewById(R.id.tilTotalCopies);

        EditText etTitle = dialogView.findViewById(R.id.etTitle);
        EditText etAuthor = dialogView.findViewById(R.id.etAuthor);
        EditText etIsbn = dialogView.findViewById(R.id.etIsbn);
        EditText etCategory = dialogView.findViewById(R.id.etCategory);
        EditText etDescription = dialogView.findViewById(R.id.etDescription);
        EditText etTotalCopies = dialogView.findViewById(R.id.etTotalCopies);

        ImageView ivCover = dialogView.findViewById(R.id.ivCover);
        Button btnSelectImage = dialogView.findViewById(R.id.btnSelectImage);

        // Auto-fill if editing
        if (book != null) {
            etTitle.setText(book.getTitle());
            etAuthor.setText(book.getAuthor());
            etIsbn.setText(book.getIsbn());
            etCategory.setText(book.getCategory());
            etDescription.setText(book.getDescription());
            etTotalCopies.setText(String.valueOf(book.getTotalCopies()));

            if (book.getCoverImage() != null && !book.getCoverImage().isEmpty()) {
                selectedCoverImageBase64 = book.getCoverImage();
                displayBase64Image(selectedCoverImageBase64, ivCover);
            }
        }

        btnSelectImage.setOnClickListener(v -> selectImageFromGallery());

        builder.setPositiveButton("Save", (dialog, which) -> {
            // Validation will be handled after dialog shows
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> {
            selectedCoverImageBase64 = ""; // Reset on cancel
        });

        AlertDialog dialog = builder.create();
        dialog.show();

        // Override positive button to handle validation
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (validateBookForm(etTitle, etAuthor, etIsbn, etCategory, etTotalCopies)) {
                saveBook(book,
                        etTitle.getText().toString().trim(),
                        etAuthor.getText().toString().trim(),
                        etIsbn.getText().toString().trim(),
                        etCategory.getText().toString().trim(),
                        etDescription.getText().toString().trim(),
                        etTotalCopies.getText().toString().trim()
                );
                dialog.dismiss();
            }
        });
    }

    private boolean validateBookForm(EditText etTitle, EditText etAuthor, EditText etIsbn,
                                     EditText etCategory, EditText etTotalCopies) {
        boolean isValid = true;

        // Clear previous errors
        etTitle.setError(null);
        etAuthor.setError(null);
        etIsbn.setError(null);
        etCategory.setError(null);
        etTotalCopies.setError(null);

        // Title validation
        if (TextUtils.isEmpty(etTitle.getText().toString().trim())) {
            etTitle.setError("Title is required");
            isValid = false;
        }

        // Author validation
        if (TextUtils.isEmpty(etAuthor.getText().toString().trim())) {
            etAuthor.setError("Author is required");
            isValid = false;
        }

        // ISBN validation (optional but must be valid if provided)
        String isbn = etIsbn.getText().toString().trim();
        if (!isbn.isEmpty() && !isValidISBN(isbn)) {
            etIsbn.setError("Invalid ISBN format (10 or 13 digits)");
            isValid = false;
        }

        // Category validation
        if (TextUtils.isEmpty(etCategory.getText().toString().trim())) {
            etCategory.setError("Category is required");
            isValid = false;
        }

        // Total copies validation
        if (TextUtils.isEmpty(etTotalCopies.getText().toString().trim())) {
            etTotalCopies.setError("Total copies is required");
            isValid = false;
        } else {
            try {
                int copies = Integer.parseInt(etTotalCopies.getText().toString().trim());
                if (copies <= 0) {
                    etTotalCopies.setError("Must be greater than 0");
                    isValid = false;
                }
            } catch (NumberFormatException e) {
                etTotalCopies.setError("Must be a valid number");
                isValid = false;
            }
        }

        return isValid;
    }

    private boolean isValidISBN(String isbn) {
        // Remove any hyphens or spaces
        String cleanIsbn = isbn.replaceAll("[\\s-]", "");

        // ISBN-10 or ISBN-13 validation
        if (cleanIsbn.length() == 10) {
            return isValidISBN10(cleanIsbn);
        } else if (cleanIsbn.length() == 13) {
            return isValidISBN13(cleanIsbn);
        }
        return false;
    }

    private boolean isValidISBN10(String isbn) {
        if (isbn.length() != 10) return false;

        int sum = 0;
        for (int i = 0; i < 9; i++) {
            int digit = isbn.charAt(i) - '0';
            if (digit < 0 || digit > 9) return false;
            sum += (digit * (10 - i));
        }

        char lastChar = isbn.charAt(9);
        if (lastChar == 'X' || lastChar == 'x') {
            sum += 10;
        } else {
            int digit = lastChar - '0';
            if (digit < 0 || digit > 9) return false;
            sum += digit;
        }

        return (sum % 11 == 0);
    }

    private boolean isValidISBN13(String isbn) {
        if (isbn.length() != 13) return false;

        int sum = 0;
        for (int i = 0; i < 12; i++) {
            int digit = isbn.charAt(i) - '0';
            if (digit < 0 || digit > 9) return false;
            sum += (digit * ((i % 2 == 0) ? 1 : 3));
        }

        int lastDigit = isbn.charAt(12) - '0';
        if (lastDigit < 0 || lastDigit > 9) return false;

        int check = (10 - (sum % 10)) % 10;
        return lastDigit == check;
    }

    private void selectImageFromGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Cover Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == getActivity().RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(requireContext().getContentResolver(), imageUri);
                // Resize image to avoid too large base64 strings
                Bitmap resizedBitmap = resizeBitmap(bitmap, 800, 800);
                // Compress and convert to base64
                selectedCoverImageBase64 = convertBitmapToBase64(resizedBitmap);

                // Show success message
                Toast.makeText(requireContext(), "Image selected successfully", Toast.LENGTH_SHORT).show();

                // Update the image view in the dialog if it's open
                updateDialogCoverImage();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(requireContext(), "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void updateDialogCoverImage() {
        // This method would need to be implemented to update the dialog's image view
        // You might need to store a reference to the dialog's ImageView
    }

    private Bitmap resizeBitmap(Bitmap bitmap, int maxWidth, int maxHeight) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        if (width > maxWidth || height > maxHeight) {
            float ratio = Math.min((float) maxWidth / width, (float) maxHeight / height);
            width = Math.round(width * ratio);
            height = Math.round(height * ratio);

            return Bitmap.createScaledBitmap(bitmap, width, height, true);
        }
        return bitmap;
    }

    private String convertBitmapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void displayBase64Image(String base64, ImageView imageView) {
        try {
            byte[] decodedString = Base64.decode(base64, Base64.DEFAULT);
            Bitmap decodedBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            imageView.setImageBitmap(decodedBitmap);
        } catch (Exception e) {
            e.printStackTrace();
            imageView.setImageResource(R.drawable.ic_book_cover_placeholder);
        }
    }

    private void saveBook(Book existingBook, String title, String author, String isbn,
                          String category, String description, String totalCopiesStr) {
        Book book = existingBook != null ? existingBook : new Book();

        book.setTitle(title);
        book.setAuthor(author);
        book.setIsbn(isbn.isEmpty() ? null : isbn);
        book.setCategory(category);
        book.setDescription(description.isEmpty() ? null : description);
        book.setCoverImage(selectedCoverImageBase64.isEmpty() ? null : selectedCoverImageBase64);
        book.setTotalCopies(Integer.parseInt(totalCopiesStr));

        // Calculate available copies
        if (existingBook != null) {
            int copyDifference = Integer.parseInt(totalCopiesStr) - existingBook.getTotalCopies();
            book.setAvailableCopies(Math.max(0, existingBook.getAvailableCopies() + copyDifference));
        } else {
            book.setAvailableCopies(Integer.parseInt(totalCopiesStr));
        }

        book.setAvailable(book.getAvailableCopies() > 0);

        SupabaseBookService.BookOperationCallback callback = new SupabaseBookService.BookOperationCallback() {
            @Override
            public void onSuccess() {
                requireActivity().runOnUiThread(() -> {
                    String message = existingBook == null ? "Book added successfully" : "Book updated successfully";
                    Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
                    loadBooks();
                    selectedCoverImageBase64 = ""; // Reset
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> {
                    String message = existingBook == null ? "Failed to add book: " : "Failed to update book: ";
                    Toast.makeText(requireContext(), message + error, Toast.LENGTH_LONG).show();
                    Log.e("BookManagement", "Save book error: " + error);
                });
            }
        };

        if (existingBook == null) {
            // Add new book to Supabase
            supabaseBookService.addBook(book, callback);
        } else {
            // Update existing book in Supabase
            supabaseBookService.updateBook(book, callback);
        }
    }

    private void showBookDetailsDialog(Book book) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Book Details");

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_book_details, null);
        builder.setView(dialogView);

        TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
        TextView tvAuthor = dialogView.findViewById(R.id.tvAuthor);
        TextView tvIsbn = dialogView.findViewById(R.id.tvIsbn);
        TextView tvCategory = dialogView.findViewById(R.id.tvCategory);
        TextView tvDescription = dialogView.findViewById(R.id.tvDescription);
        TextView tvCopies = dialogView.findViewById(R.id.tvCopies);
        ImageView ivCover = dialogView.findViewById(R.id.ivCover);

        tvTitle.setText(book.getTitle());
        tvAuthor.setText("By: " + book.getAuthor());
        tvIsbn.setText("ISBN: " + (book.getIsbn() != null && !book.getIsbn().isEmpty() ? book.getIsbn() : "N/A"));
        tvCategory.setText("Category: " + book.getCategory());
        tvDescription.setText("Description: " + (book.getDescription() != null && !book.getDescription().isEmpty() ? book.getDescription() : "N/A"));
        tvCopies.setText("Copies: " + book.getAvailableCopies() + "/" + book.getTotalCopies() + " available");

        if (book.getCoverImage() != null && !book.getCoverImage().isEmpty()) {
            displayBase64Image(book.getCoverImage(), ivCover);
        } else {
            ivCover.setImageResource(R.drawable.ic_book_cover_placeholder);
        }

        builder.setPositiveButton("Close", null);
        builder.show();
    }

    private void showBookActionsDialog(Book book) {
        String[] options = {"Edit", "Delete", "View Details"};

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Book Actions");
        builder.setItems(options, (dialog, which) -> {
            switch (which) {
                case 0: // Edit
                    showAddEditBookDialog(book);
                    break;
                case 1: // Delete
                    showDeleteConfirmationDialog(book);
                    break;
                case 2: // View Details
                    showBookDetailsDialog(book);
                    break;
            }
        });
        builder.show();
    }

    private void showDeleteConfirmationDialog(Book book) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Delete Book")
                .setMessage("Are you sure you want to delete \"" + book.getTitle() + "\"?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    supabaseBookService.deleteBook(book.getId(), new SupabaseBookService.BookOperationCallback() {
                        @Override
                        public void onSuccess() {
                            requireActivity().runOnUiThread(() -> {
                                Toast.makeText(requireContext(), "Book deleted successfully", Toast.LENGTH_SHORT).show();
                                loadBooks();
                            });
                        }

                        @Override
                        public void onError(String error) {
                            requireActivity().runOnUiThread(() -> {
                                Toast.makeText(requireContext(), "Failed to delete book: " + error, Toast.LENGTH_LONG).show();
                                Log.e("BookManagement", "Delete book error: " + error);
                            });
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // No need for onDestroy since we're not using SQLite database
}