package com.example.incredibookv2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AdminRegisterActivity extends AppCompatActivity {

    private EditText editTextAdminId, editTextEmail, editTextPassword, editTextConfirmPassword, editTextFullName;
    private Button buttonRegister;
    private TextView textViewLogin;
    private AdminAuthService adminAuthService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_register);

        initializeViews();
        setupClickListeners();

        adminAuthService = new AdminAuthService(this);
    }

    private void initializeViews() {
        editTextAdminId = findViewById(R.id.editTextAdminId);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        editTextFullName = findViewById(R.id.editTextFullName);
        buttonRegister = findViewById(R.id.buttonRegister);
        textViewLogin = findViewById(R.id.textViewLogin);
    }

    private void setupClickListeners() {
        buttonRegister.setOnClickListener(v -> handleAdminRegistration());
        textViewLogin.setOnClickListener(v -> switchToAdminLogin());
    }

    private void handleAdminRegistration() {
        String adminId = editTextAdminId.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();
        String fullName = editTextFullName.getText().toString().trim();

        if (validateInput(adminId, email, password, confirmPassword, fullName)) {
            // Show loading state
            buttonRegister.setEnabled(false);
            buttonRegister.setText("Registering...");

            registerAdmin(adminId, email, password, fullName);
        }
    }

    private boolean validateInput(String adminId, String email, String password, String confirmPassword, String fullName) {
        if (adminId.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || fullName.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void registerAdmin(String adminId, String email, String password, String fullName) {
        adminAuthService.registerAdmin(adminId, email, password, fullName,
                new SupabaseService.RegistrationCallback() {
                    @Override
                    public void onResult(boolean success) {
                        runOnUiThread(() -> {
                            buttonRegister.setEnabled(true);
                            buttonRegister.setText("Register as Admin");

                            if (success) {
                                Toast.makeText(AdminRegisterActivity.this, "Admin registration successful!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(AdminRegisterActivity.this, AdminLoginActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(AdminRegisterActivity.this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    @Override
                    public void onError(String error) {
                        runOnUiThread(() -> {
                            buttonRegister.setEnabled(true);
                            buttonRegister.setText("Register as Admin");

                            Toast.makeText(AdminRegisterActivity.this,
                                    "Registration failed: " + error, Toast.LENGTH_LONG).show();
                        });
                    }
                });
    }

    private void switchToAdminLogin() {
        Intent intent = new Intent(this, AdminLoginActivity.class);
        startActivity(intent);
        finish();
    }
}