package com.example.incredibookv2;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BorrowHistoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrow_history);
        Toast.makeText(this, "Borrow History - Coming Soon", Toast.LENGTH_SHORT).show();
    }
}