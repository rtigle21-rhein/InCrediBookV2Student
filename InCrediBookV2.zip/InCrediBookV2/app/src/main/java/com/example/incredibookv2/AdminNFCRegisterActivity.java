package com.example.incredibookv2;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputEditText;
import com.google.gson.Gson;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

public class AdminNFCRegisterActivity extends Activity {

    private static final String TAG = "AdminNFCRegisterActivity";

    private TextInputEditText editTextFullName;
    private TextInputEditText editTextAdminId;
    private TextInputEditText editTextEmail;
    private TextInputEditText editTextPassword;
    private TextInputEditText editTextConfirmPassword;
    private Button buttonRegister;
    private TextView textViewStatus;
    private TextView textViewLogin;

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private IntentFilter[] intentFiltersArray;
    private String[][] techListsArray;

    private SupabaseService supabaseService;
    private DatabaseHelper databaseHelper; // Assuming this is used for local DB operations

    private String currentNfcUid = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_nfc_register);

        initializeViews();
        setupNFC();
        setupClickListeners();

        supabaseService = new SupabaseService();
        databaseHelper = new DatabaseHelper(this);

        updateRegisterButtonState(); // Initial check
    }

    private void initializeViews() {
        editTextFullName = findViewById(R.id.editTextFullName);
        editTextAdminId = findViewById(R.id.editTextAdminId);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        buttonRegister = findViewById(R.id.buttonRegister);
        textViewStatus = findViewById(R.id.textViewStatus);
        textViewLogin = findViewById(R.id.textViewLogin);

        // Add listeners to text fields to update button state
        // (You should ensure you have this logic in place to call updateRegisterButtonState() whenever text changes)
    }

    private void setupClickListeners() {
        buttonRegister.setOnClickListener(v -> handleRegistration());
        textViewLogin.setOnClickListener(v -> switchToAdminLogin());
    }

    private void setupNFC() {
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC is not available on this device.", Toast.LENGTH_LONG).show();
            // Optional: disable NFC-related views
        } else if (!nfcAdapter.isEnabled()) {
            Toast.makeText(this, "Please enable NFC.", Toast.LENGTH_LONG).show();
        }

        Intent intent = new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE);

        // Define intent filters for NFC foreground dispatch
        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        intentFiltersArray = new IntentFilter[]{tagDetected};
        techListsArray = new String[][]{new String[]{Ndef.class.getName()}, new String[]{NdefFormatable.class.getName()}};
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        String action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action) || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action) || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)) {
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            if (tag != null) {
                currentNfcUid = bytesToHex(tag.getId());
                textViewStatus.setText("NFC Tag Scanned: " + currentNfcUid);
                updateRegisterButtonState();
            }
        }
    }

    private void handleRegistration() {
        if (!isFormValid()) {
            Toast.makeText(this, "Please fix the errors and scan an NFC tag.", Toast.LENGTH_LONG).show();
            return;
        }

        final String fullName = editTextFullName.getText().toString().trim();
        final String adminId = editTextAdminId.getText().toString().trim();
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPassword.getText().toString();
        final String nfcUid = currentNfcUid; // Assumed to be non-null by isFormValid()

        buttonRegister.setEnabled(false);
        buttonRegister.setAlpha(0.5f);
        textViewStatus.setText("Checking availability...");

        // 1. Check for existing data (Admin ID, Email, NFC UID)
        checkAllAvailability(adminId, email, nfcUid, new AvailabilityCallback() {
            @Override
            public void onAvailable() {
                // All checks passed. Proceed to register.
                Admin newAdmin = new Admin(adminId, email, password, fullName, "Admin");
                newAdmin.setNfcUid(nfcUid);
                registerWithSupabase(newAdmin, nfcUid);
            }

            @Override
            public void onNotAvailable(String message) {
                runOnUiThread(() -> {
                    Toast.makeText(AdminNFCRegisterActivity.this, message, Toast.LENGTH_LONG).show();
                    textViewStatus.setText(message);
                    buttonRegister.setEnabled(true);
                    buttonRegister.setAlpha(1.0f);
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    Toast.makeText(AdminNFCRegisterActivity.this, "Network error: " + error, Toast.LENGTH_LONG).show();
                    textViewStatus.setText("Error during checks.");
                    buttonRegister.setEnabled(true);
                    buttonRegister.setAlpha(1.0f);
                });
            }
        });
    }

    private void registerWithSupabase(final Admin newAdmin, final String nfcUid) {
        textViewStatus.setText("Registering with cloud database...");

        // The SupabaseService is now calling the RPC function with correct 'p_' prefixes
        supabaseService.registerAdminWithEmailConfirmation(newAdmin, nfcUid, new SupabaseService.RegistrationCallback() {
            @Override
            public void onResult(boolean success) {
                runOnUiThread(() -> {
                    textViewStatus.setText("Cloud registration complete.");
                    buttonRegister.setEnabled(true);
                    buttonRegister.setAlpha(1.0f);

                    if (success) {
                        // FIX: Since email verification is skipped in the function, redirect immediately
                        Toast.makeText(AdminNFCRegisterActivity.this, "Admin registered and confirmed successfully! Please log in.", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(AdminNFCRegisterActivity.this, AdminLoginActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        textViewStatus.setText("Cloud registration failed.");
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    buttonRegister.setEnabled(true);
                    buttonRegister.setAlpha(1.0f);
                    textViewStatus.setText("Registration failed.");

                    String displayError = "Registration failed: " + error;
                    Toast.makeText(AdminNFCRegisterActivity.this, displayError, Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Registration error: " + error);
                });
            }
        });
    }

    // =========================================================================
    // Validation and Utility Methods (Keep existing methods)
    // =========================================================================

    private boolean isFormValid() {
        // ... (your existing validation logic here, including password match, email format, etc.) ...
        boolean isFormFilled = !editTextFullName.getText().toString().trim().isEmpty() &&
                !editTextAdminId.getText().toString().trim().isEmpty() &&
                !editTextEmail.getText().toString().trim().isEmpty() &&
                !editTextPassword.getText().toString().isEmpty() &&
                !editTextConfirmPassword.getText().toString().isEmpty();

        boolean passwordsMatch = editTextPassword.getText().toString().equals(editTextConfirmPassword.getText().toString());
        boolean hasNfcUid = currentNfcUid != null && !currentNfcUid.isEmpty();

        // ... (You should implement robust email validation here)
        boolean isEmailValid = isEmailValid(editTextEmail.getText().toString().trim());

        if (!isFormFilled) return false;
        if (!passwordsMatch) {
            editTextConfirmPassword.setError("Passwords must match.");
            return false;
        } else {
            editTextConfirmPassword.setError(null);
        }
        if (!isEmailValid) {
            editTextEmail.setError("Invalid email format.");
            return false;
        } else {
            editTextEmail.setError(null);
        }

        if (!hasNfcUid) {
            textViewStatus.setText("Please scan your NFC card to register.");
            buttonRegister.setEnabled(false);
            buttonRegister.setAlpha(0.5f);
            return false;
        } else {
            textViewStatus.setText("NFC Tag Scanned: " + currentNfcUid);
        }

        return true;
    }

    // Simple email validation
    private boolean isEmailValid(String email) {
        return Pattern.compile("^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$").matcher(email).matches();
    }

    // Combined availability check logic
    private void checkAllAvailability(String adminId, String email, String nfcUid, AvailabilityCallback callback) {
        // Check Admin ID
        supabaseService.checkAdminIdExists(adminId, new SupabaseService.CheckExistsCallback() {
            @Override
            public void onResult(boolean exists) {
                if (exists) {
                    callback.onNotAvailable("Admin ID already exists.");
                    return;
                }

                // Check Email
                supabaseService.checkEmailExists(email, new SupabaseService.CheckExistsCallback() {
                    @Override
                    public void onResult(boolean exists) {
                        if (exists) {
                            callback.onNotAvailable("Email already registered.");
                            return;
                        }

                        // Check NFC UID
                        supabaseService.checkNFCUidExists(nfcUid, new SupabaseService.NFCUidExistsCallback() {
                            @Override
                            public void onResult(boolean exists) {
                                if (exists) {
                                    callback.onNotAvailable("NFC card already registered.");
                                    return;
                                }

                                // All clear
                                callback.onAvailable();
                            }

                            @Override
                            public void onError(String error) {
                                callback.onError(error);
                            }
                        });
                    }

                    @Override
                    public void onError(String error) {
                        callback.onError(error);
                    }
                });
            }

            @Override
            public void onError(String error) {
                callback.onError(error);
            }
        });
    }

    private interface AvailabilityCallback {
        void onAvailable();
        void onNotAvailable(String message);
        void onError(String error);
    }


    private void updateRegisterButtonState() {
        boolean isFormValid = isFormValid();
        buttonRegister.setEnabled(isFormValid);
        buttonRegister.setAlpha(isFormValid ? 1.0f : 0.5f);
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    private void switchToAdminLogin() {
        Intent intent = new Intent(this, AdminLoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nfcAdapter != null) {
            nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFiltersArray, techListsArray);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }

    // Placeholder class for local database usage (if needed)
    public static class AdminData {
        private String fullName;
        private String adminId;
        private String email;
        private String password;
        private String nfcTagId;
        private long timestamp;

        public AdminData(String fullName, String adminId, String email, String password, String nfcTagId) {
            this.fullName = fullName;
            this.adminId = adminId;
            this.email = email;
            this.password = password;
            this.nfcTagId = nfcTagId;
            this.timestamp = System.currentTimeMillis();
        }

        public String getFullName() { return fullName; }
        public String getAdminId() { return adminId; }
        public String getEmail() { return email; }
        public String getPassword() { return password; }
        public String getNfcTagId() { return nfcTagId; }
    }
}