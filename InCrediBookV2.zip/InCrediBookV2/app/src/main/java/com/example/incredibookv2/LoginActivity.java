package com.example.incredibookv2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextStudentId, editTextPassword;
    private Button buttonLogin, buttonAdminLogin;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initializeViews();
        setupClickListeners();

        sharedPreferences = getSharedPreferences("InCrediBookPrefs", MODE_PRIVATE);

        // Check if student is already logged in
        if (sharedPreferences.getBoolean("isStudentLoggedIn", false)) {
            String studentId = sharedPreferences.getString("studentId", "");
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("STUDENT_ID", studentId);
            startActivity(intent);
            finish();
        }
    }

    private void initializeViews() {
        editTextStudentId = findViewById(R.id.editTextStudentId);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonAdminLogin = findViewById(R.id.buttonAdminLogin);
    }

    private void setupClickListeners() {
        buttonLogin.setOnClickListener(v -> handleStudentLogin());
        buttonAdminLogin.setOnClickListener(v -> switchToAdminLogin());
    }

    private void handleStudentLogin() {
        String studentId = editTextStudentId.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (studentId.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter Student ID and Password", Toast.LENGTH_SHORT).show();
            return;
        }

        authenticateStudent(studentId, password);
    }

    private void authenticateStudent(String studentId, String password) {
        // Simple authentication - in real app, use Supabase
        if (studentId.equals("student") && password.equals("password")) {
            // Save login state
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isStudentLoggedIn", true);
            editor.putString("studentId", studentId);
            editor.apply();

            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("USER_TYPE", "STUDENT");
            intent.putExtra("STUDENT_ID", studentId);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid student credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void switchToAdminLogin() {
        Intent intent = new Intent(this, AdminLoginActivity.class);
        startActivity(intent);
        finish();
    }
}