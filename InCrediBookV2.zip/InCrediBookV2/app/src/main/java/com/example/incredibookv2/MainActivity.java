package com.example.incredibookv2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView textViewWelcome;
    private Button buttonSearchBooks, buttonBorrowHistory, buttonLogout;
    private EditText editTextSearch;
    private RecyclerView recyclerViewBooks;
    private BookAdapter bookAdapter;
    private List<Book> allBooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupRecyclerView();
        setupClickListeners();

        // Display student info
        String studentId = getIntent().getStringExtra("STUDENT_ID");
        textViewWelcome.setText("Welcome, Student " + studentId + "!");

        // Load sample books
        //loadSampleBooks();
    }

    private void initializeViews() {
        textViewWelcome = findViewById(R.id.textViewWelcome);
        buttonSearchBooks = findViewById(R.id.buttonSearchBooks);
        buttonBorrowHistory = findViewById(R.id.buttonBorrowHistory);
        buttonLogout = findViewById(R.id.buttonLogout);
        editTextSearch = findViewById(R.id.editTextSearch);
        recyclerViewBooks = findViewById(R.id.recyclerViewBooks);

        allBooks = new ArrayList<>();
    }

    private void setupRecyclerView() {
        recyclerViewBooks.setLayoutManager(new LinearLayoutManager(this));

        // Create a simple click listener for student view
        BookAdapter.OnBookClickListener clickListener = new BookAdapter.OnBookClickListener() {
            @Override
            public void onBookClick(Book book) {
                // Show book details for students
                showBookDetails(book);
            }

            @Override
            public void onBookLongClick(Book book) {
                // Long press might not be needed for students, or could be for borrowing
                showBorrowOptions(book);
            }
        };

        bookAdapter = new BookAdapter(new ArrayList<>(), clickListener);
        recyclerViewBooks.setAdapter(bookAdapter);
    }

    private void setupClickListeners() {
        buttonSearchBooks.setOnClickListener(v -> searchBooks());
        buttonBorrowHistory.setOnClickListener(v -> viewBorrowHistory());
        buttonLogout.setOnClickListener(v -> logout());
    }

    private void searchBooks() {
        String query = editTextSearch.getText().toString().trim();
        if (!query.isEmpty()) {
            filterBooks(query);
        } else {
            // If search is empty, show all books
            bookAdapter.updateBooks(allBooks);
        }
    }

    private void viewBorrowHistory() {
        // TODO: Implement borrow history view
        // For now, show a message
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Borrow History")
                .setMessage("Borrow history feature will be implemented soon.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void logout() {
        Intent intent = new Intent(this, AdminLoginActivity.class);
        startActivity(intent);
        finish();
    }



    private void filterBooks(String query) {
        List<Book> filteredBooks = new ArrayList<>();
        for (Book book : allBooks) {
            if (book.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                    book.getAuthor().toLowerCase().contains(query.toLowerCase()) ||
                    (book.getCategory() != null && book.getCategory().toLowerCase().contains(query.toLowerCase())) ||
                    (book.getIsbn() != null && book.getIsbn().toLowerCase().contains(query.toLowerCase()))) {
                filteredBooks.add(book);
            }
        }
        bookAdapter.updateBooks(filteredBooks);

        if (filteredBooks.isEmpty()) {
            // Show no results message
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("No Results")
                    .setMessage("No books found matching your search: " + query)
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    private void showBookDetails(Book book) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Book Details");

        String message = "Title: " + book.getTitle() + "\n" +
                "Author: " + book.getAuthor() + "\n" +
                "ISBN: " + (book.getIsbn() != null ? book.getIsbn() : "N/A") + "\n" +
                "Category: " + book.getCategory() + "\n" +
                "Description: " + (book.getDescription() != null ? book.getDescription() : "N/A") + "\n" +
                "Status: " + (book.isAvailable() ? "Available" : "Not Available") + "\n" +
                "Copies: " + book.getAvailableCopies() + "/" + book.getTotalCopies() + " available";

        builder.setMessage(message)
                .setPositiveButton("OK", null);

        if (book.isAvailable()) {
            builder.setNeutralButton("Borrow Book", (dialog, which) -> {
                borrowBook(book);
            });
        }

        builder.show();
    }

    private void showBorrowOptions(Book book) {
        if (book.isAvailable()) {
            borrowBook(book);
        } else {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("Book Not Available")
                    .setMessage("Sorry, \"" + book.getTitle() + "\" is currently not available for borrowing.")
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    private void borrowBook(Book book) {
        // TODO: Implement actual borrowing logic with Supabase
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Borrow Book")
                .setMessage("Borrow \"" + book.getTitle() + "\"?\n\nThis feature will be integrated with the borrowing system.")
                .setPositiveButton("Borrow", (dialog, which) -> {
                    // Simulate successful borrowing
                    Toast.makeText(this, "Book borrowed successfully!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Add this method to handle back button press
    @Override
    public void onBackPressed() {
        // If search has results, clear search and show all books
        if (!editTextSearch.getText().toString().isEmpty()) {
            editTextSearch.setText("");
            bookAdapter.updateBooks(allBooks);
        } else {
            super.onBackPressed();
        }
    }
}