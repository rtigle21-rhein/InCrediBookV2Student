package com.example.incredibookv2;

public class NFCAuthAdmin {
    private String id;
    private String adminId;
    private String nfcUid;
    private String email;
    private String fullName;
    private String role;
    private boolean emailConfirmed;
    private String createdAt;

    public NFCAuthAdmin() {}

    public NFCAuthAdmin(String adminId, String nfcUid, String email, String fullName, String role) {
        this.adminId = adminId;
        this.nfcUid = nfcUid;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
    }

    // Constructor for your existing usage


    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getAdminId() { return adminId; }
    public void setAdminId(String adminId) { this.adminId = adminId; }

    public String getNfcUid() { return nfcUid; }
    public void setNfcUid(String nfcUid) { this.nfcUid = nfcUid; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public boolean isEmailConfirmed() { return emailConfirmed; }
    public void setEmailConfirmed(boolean emailConfirmed) { this.emailConfirmed = emailConfirmed; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}