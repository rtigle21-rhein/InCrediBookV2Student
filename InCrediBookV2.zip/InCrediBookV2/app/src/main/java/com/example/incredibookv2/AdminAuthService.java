package com.example.incredibookv2;

import android.content.Context;
import android.util.Log;

public class AdminAuthService {
    private static final String TAG = "AdminAuthService";
    private SupabaseService supabaseService;

    public AdminAuthService(Context context) {
        this.supabaseService = new SupabaseService();
    }

    public void registerAdmin(String adminId, String email, String password, String fullName,
                              SupabaseService.RegistrationCallback callback) {
        Log.d(TAG, "Starting registration for admin: " + adminId);

        // First check if admin ID exists
        supabaseService.checkAdminIdExists(adminId, new SupabaseService.CheckExistsCallback() {
            @Override
            public void onResult(boolean exists) {
                if (exists) {
                    Log.e(TAG, "Admin ID already exists: " + adminId);
                    callback.onError("Admin ID already exists");
                } else {
                    // Check if email exists
                    supabaseService.checkEmailExists(email, new SupabaseService.CheckExistsCallback() {
                        @Override
                        public void onResult(boolean emailExists) {
                            if (emailExists) {
                                Log.e(TAG, "Email already exists: " + email);
                                callback.onError("Email already registered");
                            } else {
                                // All checks passed, proceed with registration
                                Admin newAdmin = new Admin(adminId, email, password, fullName, "admin");
                                supabaseService.registerAdmin(newAdmin, callback);
                            }
                        }

                        @Override
                        public void onError(String error) {
                            Log.e(TAG, "Error checking email: " + error);
                            callback.onError("Error checking email: " + error);
                        }
                    });
                }
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Error checking admin ID: " + error);
                callback.onError("Error checking admin ID: " + error);
            }
        });
    }

    // Register admin with email confirmation and NFC
    public void registerAdminWithEmailConfirmation(String adminId, String fullName, String email,
                                                   String password, String nfcUid,
                                                   SupabaseService.RegistrationCallback callback) {
        Log.d(TAG, "Starting registration with email confirmation for admin: " + adminId + " with NFC: " + nfcUid);

        // First check if admin ID exists
        supabaseService.checkAdminIdExists(adminId, new SupabaseService.CheckExistsCallback() {
            @Override
            public void onResult(boolean adminIdExists) {
                if (adminIdExists) {
                    Log.e(TAG, "Admin ID already exists: " + adminId);
                    callback.onError("Admin ID already exists");
                    return;
                }

                // Check if NFC UID exists
                supabaseService.checkNFCUidExists(nfcUid, new SupabaseService.NFCUidExistsCallback() {
                    @Override
                    public void onResult(boolean nfcExists) {
                        if (nfcExists) {
                            Log.e(TAG, "NFC UID already exists: " + nfcUid);
                            callback.onError("NFC card already registered to another admin");
                            return;
                        }

                        // Check if email exists
                        supabaseService.checkEmailExists(email, new SupabaseService.CheckExistsCallback() {
                            @Override
                            public void onResult(boolean emailExists) {
                                if (emailExists) {
                                    Log.e(TAG, "Email already exists: " + email);
                                    callback.onError("Email already registered");
                                    return;
                                }

                                // All checks passed, proceed with registration
                                Admin newAdmin = new Admin(adminId, email, password, fullName, "admin");
                                supabaseService.registerAdminWithEmailConfirmation(newAdmin, nfcUid, callback);
                            }

                            @Override
                            public void onError(String error) {
                                Log.e(TAG, "Error checking email: " + error);
                                callback.onError("Error checking email: " + error);
                            }
                        });
                    }

                    @Override
                    public void onError(String error) {
                        Log.e(TAG, "Error checking NFC UID: " + error);
                        callback.onError("Error checking NFC card: " + error);
                    }
                });
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Error checking admin ID: " + error);
                callback.onError("Error checking admin ID: " + error);
            }
        });
    }

    public void loginAdmin(String adminId, String password, SupabaseService.LoginCallback callback) {
        Log.d(TAG, "Attempting login for admin: " + adminId);
        supabaseService.loginAdmin(adminId, password, callback);
    }

    public void loginAdminWithNFC(String nfcUid, SupabaseService.NFCLoginCallback callback) {
        Log.d(TAG, "Attempting NFC login for admin with UID: " + nfcUid);
        supabaseService.loginAdminWithNFC(nfcUid, callback);
    }

    public void registerNFCAdmin(String adminId, String nfcUid, String email, String fullName,
                                 SupabaseService.RegistrationCallback callback) {
        Log.d(TAG, "Starting NFC registration for admin: " + adminId + " with UID: " + nfcUid);

        // First check if NFC UID exists
        supabaseService.checkNFCUidExists(nfcUid, new SupabaseService.NFCUidExistsCallback() {
            @Override
            public void onResult(boolean exists) {
                if (exists) {
                    Log.e(TAG, "NFC UID already exists: " + nfcUid);
                    callback.onError("NFC card already registered to another admin");
                } else {
                    // Create new NFC admin and register
                    NFCAuthAdmin newNFCAdmin = new NFCAuthAdmin(adminId, nfcUid, email, fullName, "admin");
                    supabaseService.registerNFCAdmin(newNFCAdmin, callback);
                }
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Error checking NFC UID: " + error);
                callback.onError("Error checking NFC card: " + error);
            }
        });
    }

    public void checkNFCUidExists(String nfcUid, SupabaseService.NFCUidExistsCallback callback) {
        Log.d(TAG, "Checking if NFC UID exists: " + nfcUid);
        supabaseService.checkNFCUidExists(nfcUid, callback);
    }

    public void checkAdminIdExists(String adminId, SupabaseService.CheckExistsCallback callback) {
        Log.d(TAG, "Checking if admin ID exists: " + adminId);
        supabaseService.checkAdminIdExists(adminId, callback);
    }

    public void checkEmailExists(String email, SupabaseService.CheckExistsCallback callback) {
        Log.d(TAG, "Checking if email exists: " + email);
        supabaseService.checkEmailExists(email, callback);
    }
}