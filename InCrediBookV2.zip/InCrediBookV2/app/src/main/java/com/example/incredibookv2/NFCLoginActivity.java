package com.example.incredibookv2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

public class NFCLoginActivity extends AppCompatActivity implements NfcAdapter.ReaderCallback {

    private TextView textViewStatus;
    private Button buttonManualLogin;
    private NfcAdapter nfcAdapter;
    private SharedPreferences sharedPreferences;
    private AdminAuthService adminAuthService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nfc_login);

        initializeViews();
        setupNFC();
        setupClickListeners();

        sharedPreferences = getSharedPreferences("InCrediBookPrefs", MODE_PRIVATE);
        adminAuthService = new AdminAuthService(this);

        // Check if admin is already logged in
        if (sharedPreferences.getBoolean("isAdminLoggedIn", false)) {
            startActivity(new Intent(this, AdminActivity.class));
            finish();
        }
    }

    private void initializeViews() {
        textViewStatus = findViewById(R.id.textViewStatus);
        buttonManualLogin = findViewById(R.id.buttonManualLogin);
    }

    private void setupClickListeners() {
        buttonManualLogin.setOnClickListener(v -> switchToManualLogin());
    }

    private void setupNFC() {
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC is not available on this device.", Toast.LENGTH_LONG).show();
            textViewStatus.setText("NFC not available on this device");
        } else if (!nfcAdapter.isEnabled()) {
            Toast.makeText(this, "Please enable NFC to log in.", Toast.LENGTH_LONG).show();
            textViewStatus.setText("Please enable NFC");
        } else {
            textViewStatus.setText("Ready - Tap your NFC card to login");
        }
    }

    @Override
    public void onTagDiscovered(Tag tag) {
        String nfcUid = bytesToHex(tag.getId());
        runOnUiThread(() -> {
            textViewStatus.setText("NFC Tag Discovered. Attempting login...");
            authenticateWithNFC(nfcUid);
        });
    }

    private void authenticateWithNFC(final String nfcUid) {
        adminAuthService.loginAdminWithNFC(nfcUid, new SupabaseService.NFCLoginCallback() {
            @Override
            public void onResult(NFCAuthAdmin admin) {
                runOnUiThread(() -> {
                    if (admin != null) {
                        textViewStatus.setText("Admin logged in via NFC.");
                        saveNFCAdminDetails(admin);
                        Intent intent = new Intent(NFCLoginActivity.this, AdminActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        textViewStatus.setText("Authentication failed. NFC card not registered or not found.");
                        Toast.makeText(NFCLoginActivity.this,
                                "NFC card not registered or not found", Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    textViewStatus.setText("Authentication failed. Tap again.");
                    Toast.makeText(NFCLoginActivity.this,
                            "NFC Login failed: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void saveNFCAdminDetails(NFCAuthAdmin admin) {
        // FIX: Use full name instead of email for display
        String displayName = admin.getFullName();

        // If full name is not available, use admin ID as fallback (NOT email)
        if (displayName == null || displayName.trim().isEmpty()) {
            displayName = admin.getAdminId();
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isAdminLoggedIn", true);
        editor.putString("adminId", admin.getAdminId());
        editor.putString("adminFullName", displayName); // This is what gets displayed
        editor.putString("adminEmail", admin.getEmail());
        editor.putBoolean("hasNFCRegistered", true);
        editor.putString("nfcUid", admin.getNfcUid());
        editor.apply();

        Log.d("NFCLogin", "Saved admin details - FullName: " + displayName + ", Email: " + admin.getEmail());
    }

    // Convert byte array to hex string
    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    private void switchToManualLogin() {
        Intent intent = new Intent(this, AdminLoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nfcAdapter != null && nfcAdapter.isEnabled()) {
            nfcAdapter.enableReaderMode(this, this,
                    NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK, null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) {
            nfcAdapter.disableReaderMode(this);
        }
    }
}