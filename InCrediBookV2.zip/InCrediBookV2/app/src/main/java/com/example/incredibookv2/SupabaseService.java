package com.example.incredibookv2;

import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import okhttp3.*;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;

public class SupabaseService {
    private static final String TAG = "SupabaseService";
    private static final String SUPABASE_URL = "https://qwbmmetkxaluxwpinlee.supabase.co/rest/v1/";
    private static final String SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF3Ym1tZXRreGFsdXh3cGlubGVlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0NDk4NDcsImV4cCI6MjA3OTAyNTg0N30.DRQuRm2GoU-UEO17P4FFdBudlenraLatfT6uAuBQk70";

    private OkHttpClient client;
    private Gson gson;

    public SupabaseService() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
        this.gson = new Gson();
    }

    // Interfaces
    public interface RegistrationCallback {
        void onResult(boolean success);
        void onError(String error);
    }

    public interface LoginCallback {
        void onResult(Admin admin);
        void onError(String error);
    }

    public interface CheckExistsCallback {
        void onResult(boolean exists);
        void onError(String error);
    }

    public interface NFCLoginCallback {
        void onResult(NFCAuthAdmin admin);
        void onError(String error);
    }

    public interface NFCUidExistsCallback {
        void onResult(boolean exists);
        void onError(String error);
    }

    // Method 1: Register admin with email confirmation and NFC
    public void registerAdminWithEmailConfirmation(Admin admin, String nfcUid, RegistrationCallback callback) {
        Log.d(TAG, "Registering admin with immediate confirmation: " + admin.getAdminId());

        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("p_admin_id", admin.getAdminId());
            requestBody.put("p_full_name", admin.getFullName());
            requestBody.put("p_email", admin.getEmail());
            requestBody.put("p_password", admin.getPassword());
            requestBody.put("p_nfc_uid", nfcUid);
            requestBody.put("p_role", admin.getRole());

            RequestBody body = RequestBody.create(
                    requestBody.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "rpc/register_admin_with_nfc_confirmation")
                    .post(body)
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Registration error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d(TAG, "Registration successful for admin: " + admin.getAdminId());
                        callback.onResult(true);
                    } else {
                        String errorMessage = "Registration failed";
                        try {
                            String responseBody = response.body().string();
                            Log.e(TAG, "Registration failed response: " + responseBody);

                            if (responseBody.contains("Admin ID already exists")) {
                                errorMessage = "Admin ID already exists";
                            } else if (responseBody.contains("Email already registered")) {
                                errorMessage = "Email already registered";
                            } else if (responseBody.contains("NFC card already registered")) {
                                errorMessage = "NFC card already registered";
                            } else if (response.code() == 400) {
                                errorMessage = "Invalid request data. Check logs.";
                            } else if (response.code() == 500) {
                                errorMessage = "Server error during registration";
                            }
                        } catch (Exception e) {
                            errorMessage = "Registration failed with code: " + response.code();
                        }
                        callback.onError(errorMessage);
                    }
                }
            });

        } catch (JSONException e) {
            Log.e(TAG, "JSON error in registration: " + e.getMessage());
            callback.onError("JSON error: " + e.getMessage());
        }
    }

    // Method 2: NFC Login - Check admins table for NFC UID (FIXED)
    public void loginAdminWithNFC(String nfcUid, NFCLoginCallback callback) {
        Log.d(TAG, "Attempting NFC login with UID: " + nfcUid);

        try {
            String encodedNfcUid = URLEncoder.encode(nfcUid, "UTF-8");
            String url = SUPABASE_URL + "admins?nfc_uid=eq." + encodedNfcUid + "&select=*";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "NFC login network error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            Log.d(TAG, "NFC login response: " + responseBody);

                            if (responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty()) {
                                JsonArray jsonArray = JsonParser.parseString(responseBody).getAsJsonArray();
                                if (jsonArray.size() > 0) {
                                    // Convert to Admin object first to get all fields
                                    Admin admin = gson.fromJson(jsonArray.get(0), Admin.class);

                                    // DEBUG: Log what we're getting from the database
                                    Log.d(TAG, "Admin data from NFC - FullName: " + admin.getFullName() +
                                            ", Email: " + admin.getEmail() +
                                            ", AdminId: " + admin.getAdminId());

                                    // Create NFCAuthAdmin with CORRECT field mapping
                                    NFCAuthAdmin nfcAdmin = new NFCAuthAdmin();
                                    nfcAdmin.setId(admin.getId());
                                    nfcAdmin.setAdminId(admin.getAdminId());
                                    nfcAdmin.setNfcUid(admin.getNfcUid());
                                    nfcAdmin.setEmail(admin.getEmail());
                                    nfcAdmin.setFullName(admin.getFullName()); // THIS IS THE KEY FIX
                                    nfcAdmin.setRole(admin.getRole());
                                    nfcAdmin.setEmailConfirmed(admin.isEmailConfirmed());

                                    callback.onResult(nfcAdmin);
                                    return;
                                }
                            }
                            callback.onResult(null);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing NFC login response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "NFC login failed: " + response.code() + " - " + errorBody);
                        callback.onError("Login failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in NFC login: " + e.getMessage());
            callback.onError("Login error: " + e.getMessage());
        }
    }

    // Method 3: Manual Admin Login
    public void loginAdmin(String adminId, String password, LoginCallback callback) {
        Log.d(TAG, "Attempting manual login for admin: " + adminId);

        try {
            String encodedAdminId = URLEncoder.encode(adminId, "UTF-8");
            String url = SUPABASE_URL + "admins?admin_id=eq." + encodedAdminId + "&select=*";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Login network error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            Log.d(TAG, "Login response: " + responseBody);

                            if (responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty()) {
                                JsonArray jsonArray = JsonParser.parseString(responseBody).getAsJsonArray();
                                if (jsonArray.size() > 0) {
                                    Admin admin = gson.fromJson(jsonArray.get(0), Admin.class);

                                    // Verify password
                                    if (admin.getPassword() != null && admin.getPassword().equals(password)) {
                                        callback.onResult(admin);
                                    } else {
                                        callback.onResult(null);
                                    }
                                    return;
                                }
                            }
                            callback.onResult(null);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing login response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "Login failed: " + response.code() + " - " + errorBody);
                        callback.onError("Login failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in login: " + e.getMessage());
            callback.onError("Login error: " + e.getMessage());
        }
    }

    // Method 4: Check if Admin ID exists
    public void checkAdminIdExists(String adminId, CheckExistsCallback callback) {
        Log.d(TAG, "Checking if admin ID exists: " + adminId);

        try {
            String encodedAdminId = URLEncoder.encode(adminId, "UTF-8");
            String url = SUPABASE_URL + "admins?admin_id=eq." + encodedAdminId + "&select=admin_id";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Error checking admin ID: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            boolean exists = responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty();
                            callback.onResult(exists);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing admin ID check response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "Admin ID check failed: " + response.code() + " - " + errorBody);
                        callback.onError("Check failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in admin ID check: " + e.getMessage());
            callback.onError("Check error: " + e.getMessage());
        }
    }

    // Method 5: Check if Email exists
    public void checkEmailExists(String email, CheckExistsCallback callback) {
        Log.d(TAG, "Checking if email exists: " + email);

        try {
            String encodedEmail = URLEncoder.encode(email, "UTF-8");
            String url = SUPABASE_URL + "admins?email=eq." + encodedEmail + "&select=email";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Error checking email: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            boolean exists = responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty();
                            callback.onResult(exists);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing email check response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "Email check failed: " + response.code() + " - " + errorBody);
                        callback.onError("Check failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in email check: " + e.getMessage());
            callback.onError("Check error: " + e.getMessage());
        }
    }

    // Method 6: Check if NFC UID exists
    public void checkNFCUidExists(String nfcUid, NFCUidExistsCallback callback) {
        Log.d(TAG, "Checking if NFC UID exists: " + nfcUid);

        try {
            String encodedNfcUid = URLEncoder.encode(nfcUid, "UTF-8");
            String url = SUPABASE_URL + "admins?nfc_uid=eq." + encodedNfcUid + "&select=nfc_uid";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Error checking NFC UID: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            boolean exists = responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty();
                            callback.onResult(exists);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing NFC UID check response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "NFC UID check failed: " + response.code() + " - " + errorBody);
                        callback.onError("Check failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in NFC UID check: " + e.getMessage());
            callback.onError("Check error: " + e.getMessage());
        }
    }

    // Method 7: Simple admin registration (without NFC)
    public void registerAdmin(Admin admin, RegistrationCallback callback) {
        Log.d(TAG, "Registering admin: " + admin.getAdminId());

        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("admin_id", admin.getAdminId());
            requestBody.put("email", admin.getEmail());
            requestBody.put("password", admin.getPassword());
            requestBody.put("full_name", admin.getFullName());
            requestBody.put("role", admin.getRole());

            RequestBody body = RequestBody.create(
                    requestBody.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "admins")
                    .post(body)
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Registration error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d(TAG, "Registration successful for admin: " + admin.getAdminId());
                        callback.onResult(true);
                    } else {
                        String errorMessage = "Registration failed";
                        try {
                            String responseBody = response.body().string();
                            Log.e(TAG, "Registration failed response: " + responseBody);

                            if (responseBody.contains("duplicate key") && responseBody.contains("admin_id")) {
                                errorMessage = "Admin ID already exists";
                            } else if (responseBody.contains("duplicate key") && responseBody.contains("email")) {
                                errorMessage = "Email already registered";
                            } else if (response.code() == 400) {
                                errorMessage = "Invalid request data";
                            } else if (response.code() == 500) {
                                errorMessage = "Server error during registration";
                            }
                        } catch (Exception e) {
                            errorMessage = "Registration failed with code: " + response.code();
                        }
                        callback.onError(errorMessage);
                    }
                }
            });

        } catch (JSONException e) {
            Log.e(TAG, "JSON error in registration: " + e.getMessage());
            callback.onError("JSON error: " + e.getMessage());
        }
    }

    // Method 8: Register NFC Admin (legacy method)
    public void registerNFCAdmin(NFCAuthAdmin admin, RegistrationCallback callback) {
        Log.d(TAG, "Registering NFC admin: " + admin.getAdminId());

        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("admin_id", admin.getAdminId());
            requestBody.put("email", admin.getEmail());
            requestBody.put("full_name", admin.getFullName());
            requestBody.put("nfc_uid", admin.getNfcUid());
            requestBody.put("role", admin.getRole());

            RequestBody body = RequestBody.create(
                    requestBody.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "nfc_auth_admins")
                    .post(body)
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "NFC registration error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d(TAG, "NFC registration successful for admin: " + admin.getAdminId());
                        callback.onResult(true);
                    } else {
                        String errorMessage = "NFC registration failed";
                        try {
                            String responseBody = response.body().string();
                            Log.e(TAG, "NFC registration failed response: " + responseBody);
                            errorMessage = "Registration failed with code: " + response.code();
                        } catch (Exception e) {
                            errorMessage = "Registration failed with code: " + response.code();
                        }
                        callback.onError(errorMessage);
                    }
                }
            });

        } catch (JSONException e) {
            Log.e(TAG, "JSON error in NFC registration: " + e.getMessage());
            callback.onError("JSON error: " + e.getMessage());
        }
    }
}