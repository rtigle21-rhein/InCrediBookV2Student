package com.example.incredibookv2;

import android.content.Context;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class SupabaseBookService {
    private static final String TAG = "SupabaseBookService";
    private static final String SUPABASE_URL = "https://qwbmmetkxaluxwpinlee.supabase.co";
    private static final String API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF3Ym1tZXRreGFsdXh3cGlubGVlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0NDk4NDcsImV4cCI6MjA3OTAyNTg0N30.DRQuRm2GoU-UEO17P4FFdBudlenraLatfT6uAuBQk70";

    private OkHttpClient client;
    private Gson gson;
    private Context context;

    public SupabaseBookService(Context context) {
        this.context = context;
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
        this.gson = new Gson();
    }

    public interface BookOperationCallback {
        void onSuccess();
        void onError(String error);
    }

    public interface BooksFetchCallback {
        void onSuccess(List<Book> books);
        void onError(String error);
    }

    // Get all books
    public void getAllBooks(BooksFetchCallback callback) {
        Request request = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/books?select=*")
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", "Bearer " + API_KEY)
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to fetch books: " + e.getMessage());
                callback.onError("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    try {
                        Type bookListType = new TypeToken<List<Book>>(){}.getType();
                        List<Book> books = gson.fromJson(responseBody, bookListType);
                        callback.onSuccess(books);
                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing books: " + e.getMessage());
                        callback.onError("Error parsing data");
                    }
                } else {
                    callback.onError("Server error: " + response.code());
                }
            }
        });
    }

    // Add new book
    public void addBook(Book book, BookOperationCallback callback) {
        try {
            JSONObject bookJson = new JSONObject();
            bookJson.put("title", book.getTitle());
            bookJson.put("author", book.getAuthor());
            bookJson.put("isbn", book.getIsbn());
            bookJson.put("category", book.getCategory());
            bookJson.put("description", book.getDescription());
            bookJson.put("cover_image", book.getCoverImage());
            bookJson.put("available", book.isAvailable());
            bookJson.put("total_copies", book.getTotalCopies());
            bookJson.put("available_copies", book.getAvailableCopies());

            RequestBody body = RequestBody.create(
                    bookJson.toString(),
                    MediaType.parse("application/json")
            );

            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/books")
                    .addHeader("apikey", API_KEY)
                    .addHeader("Authorization", "Bearer " + API_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .post(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    callback.onError("Network error: " + e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        callback.onSuccess();
                    } else {
                        callback.onError("Server error: " + response.code());
                    }
                }
            });
        } catch (JSONException e) {
            callback.onError("Error creating book data: " + e.getMessage());
        }
    }

    // Update book
    public void updateBook(Book book, BookOperationCallback callback) {
        try {
            JSONObject bookJson = new JSONObject();
            bookJson.put("title", book.getTitle());
            bookJson.put("author", book.getAuthor());
            bookJson.put("isbn", book.getIsbn());
            bookJson.put("category", book.getCategory());
            bookJson.put("description", book.getDescription());
            bookJson.put("cover_image", book.getCoverImage());
            bookJson.put("available", book.isAvailable());
            bookJson.put("total_copies", book.getTotalCopies());
            bookJson.put("available_copies", book.getAvailableCopies());

            RequestBody body = RequestBody.create(
                    bookJson.toString(),
                    MediaType.parse("application/json")
            );

            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/books?id=eq." + book.getId())
                    .addHeader("apikey", API_KEY)
                    .addHeader("Authorization", "Bearer " + API_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .patch(body)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    callback.onError("Network error: " + e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        callback.onSuccess();
                    } else {
                        callback.onError("Server error: " + response.code());
                    }
                }
            });
        } catch (JSONException e) {
            callback.onError("Error updating book data: " + e.getMessage());
        }
    }

    // Delete book
    public void deleteBook(String bookId, BookOperationCallback callback) {
        Request request = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/books?id=eq." + bookId)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", "Bearer " + API_KEY)
                .addHeader("Prefer", "return=minimal")
                .delete()
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onError("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onSuccess();
                } else {
                    callback.onError("Server error: " + response.code());
                }
            }
        });
    }
}