// BookDatabaseHelper.java
package com.example.incredibookv2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class BookDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InCrediBook.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_BOOKS = "books";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_AUTHOR = "author";
    private static final String COLUMN_ISBN = "isbn";
    private static final String COLUMN_CATEGORY = "category";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_COVER_IMAGE = "cover_image";
    private static final String COLUMN_AVAILABLE = "available";
    private static final String COLUMN_TOTAL_COPIES = "total_copies";
    private static final String COLUMN_AVAILABLE_COPIES = "available_copies";

    public BookDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_BOOKS_TABLE = "CREATE TABLE " + TABLE_BOOKS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TITLE + " TEXT NOT NULL,"
                + COLUMN_AUTHOR + " TEXT NOT NULL,"
                + COLUMN_ISBN + " TEXT,"
                + COLUMN_CATEGORY + " TEXT NOT NULL,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_COVER_IMAGE + " TEXT,"
                + COLUMN_AVAILABLE + " INTEGER DEFAULT 1,"
                + COLUMN_TOTAL_COPIES + " INTEGER DEFAULT 1,"
                + COLUMN_AVAILABLE_COPIES + " INTEGER DEFAULT 1"
                + ")";
        db.execSQL(CREATE_BOOKS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKS);
        onCreate(db);
    }

    public boolean addBook(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, book.getTitle());
        values.put(COLUMN_AUTHOR, book.getAuthor());
        values.put(COLUMN_ISBN, book.getIsbn());
        values.put(COLUMN_CATEGORY, book.getCategory());
        values.put(COLUMN_DESCRIPTION, book.getDescription());
        values.put(COLUMN_COVER_IMAGE, book.getCoverImage());
        values.put(COLUMN_AVAILABLE, book.isAvailable() ? 1 : 0);
        values.put(COLUMN_TOTAL_COPIES, book.getTotalCopies());
        values.put(COLUMN_AVAILABLE_COPIES, book.getAvailableCopies());

        long result = db.insert(TABLE_BOOKS, null, values);
        db.close();
        return result != -1;
    }

    public List<Book> getAllBooks() {
        List<Book> bookList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_BOOKS, null);

        if (cursor.moveToFirst()) {
            do {
                Book book = new Book();
                book.setId(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                book.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
                book.setAuthor(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AUTHOR)));
                book.setIsbn(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ISBN)));
                book.setCategory(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY)));
                book.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)));
                book.setCoverImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COVER_IMAGE)));
                book.setAvailable(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_AVAILABLE)) == 1);
                book.setTotalCopies(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_COPIES)));
                book.setAvailableCopies(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_AVAILABLE_COPIES)));

                bookList.add(book);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return bookList;
    }

    public boolean updateBook(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, book.getTitle());
        values.put(COLUMN_AUTHOR, book.getAuthor());
        values.put(COLUMN_ISBN, book.getIsbn());
        values.put(COLUMN_CATEGORY, book.getCategory());
        values.put(COLUMN_DESCRIPTION, book.getDescription());
        values.put(COLUMN_COVER_IMAGE, book.getCoverImage());
        values.put(COLUMN_AVAILABLE, book.isAvailable() ? 1 : 0);
        values.put(COLUMN_TOTAL_COPIES, book.getTotalCopies());
        values.put(COLUMN_AVAILABLE_COPIES, book.getAvailableCopies());

        int result = db.update(TABLE_BOOKS, values, COLUMN_ID + " = ?",
                new String[]{book.getId()});
        db.close();
        return result > 0;
    }

    public boolean deleteBook(String bookId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_BOOKS, COLUMN_ID + " = ?", new String[]{bookId});
        db.close();
        return result > 0;
    }

    public Book getBookById(String bookId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_BOOKS, null, COLUMN_ID + " = ?",
                new String[]{bookId}, null, null, null);

        Book book = null;
        if (cursor != null && cursor.moveToFirst()) {
            book = new Book();
            book.setId(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ID)));
            book.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
            book.setAuthor(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_AUTHOR)));
            book.setIsbn(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ISBN)));
            book.setCategory(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY)));
            book.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)));
            book.setCoverImage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COVER_IMAGE)));
            book.setAvailable(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_AVAILABLE)) == 1);
            book.setTotalCopies(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_COPIES)));
            book.setAvailableCopies(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_AVAILABLE_COPIES)));
            cursor.close();
        }
        db.close();
        return book;
    }
}