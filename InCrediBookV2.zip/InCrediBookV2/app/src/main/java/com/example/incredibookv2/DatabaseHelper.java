package com.example.incredibookv2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHelper";

    // Database Information
    private static final String DATABASE_NAME = "Incredibook.db";
    private static final int DATABASE_VERSION = 1;

    // Table Names
    private static final String TABLE_ADMINS = "admins";
    private static final String TABLE_USERS = "users";
    private static final String TABLE_BOOKS = "books";
    private static final String TABLE_BORROW_RECORDS = "borrow_records";

    // Common column names
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_CREATED_AT = "created_at";

    // Admins Table columns
    private static final String COLUMN_FULL_NAME = "full_name";
    private static final String COLUMN_ADMIN_ID = "admin_id";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_NFC_TAG_ID = "nfc_tag_id";

    // Users Table columns
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_FULL_NAME = "full_name";
    private static final String COLUMN_USER_EMAIL = "email";
    private static final String COLUMN_USER_PHONE = "phone";
    private static final String COLUMN_USER_NFC_TAG_ID = "nfc_tag_id";

    // Books Table columns
    private static final String COLUMN_BOOK_ID = "book_id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_AUTHOR = "author";
    private static final String COLUMN_ISBN = "isbn";
    private static final String COLUMN_PUBLISHER = "publisher";
    private static final String COLUMN_YEAR = "year";
    private static final String COLUMN_GENRE = "genre";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_QUANTITY = "quantity";
    private static final String COLUMN_AVAILABLE = "available";
    private static final String COLUMN_LOCATION = "location";

    // Borrow Records Table columns
    private static final String COLUMN_BORROW_ID = "borrow_id";
    private static final String COLUMN_USER_NFC = "user_nfc";
    private static final String COLUMN_BOOK_ISBN = "book_isbn";
    private static final String COLUMN_BORROW_DATE = "borrow_date";
    private static final String COLUMN_DUE_DATE = "due_date";
    private static final String COLUMN_RETURN_DATE = "return_date";
    private static final String COLUMN_STATUS = "status"; // borrowed, returned, overdue
    private static final String COLUMN_FINE_AMOUNT = "fine_amount";

    // Create Tables SQL
    private static final String CREATE_TABLE_ADMINS = "CREATE TABLE " + TABLE_ADMINS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_FULL_NAME + " TEXT NOT NULL,"
            + COLUMN_ADMIN_ID + " TEXT UNIQUE NOT NULL,"
            + COLUMN_EMAIL + " TEXT UNIQUE NOT NULL,"
            + COLUMN_PASSWORD + " TEXT NOT NULL,"
            + COLUMN_NFC_TAG_ID + " TEXT UNIQUE NOT NULL,"
            + COLUMN_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";

    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USER_ID + " TEXT UNIQUE NOT NULL,"
            + COLUMN_USER_FULL_NAME + " TEXT NOT NULL,"
            + COLUMN_USER_EMAIL + " TEXT,"
            + COLUMN_USER_PHONE + " TEXT,"
            + COLUMN_USER_NFC_TAG_ID + " TEXT UNIQUE NOT NULL,"
            + COLUMN_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";

    private static final String CREATE_TABLE_BOOKS = "CREATE TABLE " + TABLE_BOOKS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_BOOK_ID + " TEXT UNIQUE NOT NULL,"
            + COLUMN_TITLE + " TEXT NOT NULL,"
            + COLUMN_AUTHOR + " TEXT NOT NULL,"
            + COLUMN_ISBN + " TEXT UNIQUE NOT NULL,"
            + COLUMN_PUBLISHER + " TEXT,"
            + COLUMN_YEAR + " INTEGER,"
            + COLUMN_GENRE + " TEXT,"
            + COLUMN_DESCRIPTION + " TEXT,"
            + COLUMN_QUANTITY + " INTEGER DEFAULT 1,"
            + COLUMN_AVAILABLE + " INTEGER DEFAULT 1,"
            + COLUMN_LOCATION + " TEXT,"
            + COLUMN_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";

    private static final String CREATE_TABLE_BORROW_RECORDS = "CREATE TABLE " + TABLE_BORROW_RECORDS + "("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_BORROW_ID + " TEXT UNIQUE NOT NULL,"
            + COLUMN_USER_NFC + " TEXT NOT NULL,"
            + COLUMN_BOOK_ISBN + " TEXT NOT NULL,"
            + COLUMN_BORROW_DATE + " DATETIME DEFAULT CURRENT_TIMESTAMP,"
            + COLUMN_DUE_DATE + " DATETIME,"
            + COLUMN_RETURN_DATE + " DATETIME,"
            + COLUMN_STATUS + " TEXT DEFAULT 'borrowed',"
            + COLUMN_FINE_AMOUNT + " REAL DEFAULT 0,"
            + "FOREIGN KEY(" + COLUMN_USER_NFC + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_NFC_TAG_ID + "),"
            + "FOREIGN KEY(" + COLUMN_BOOK_ISBN + ") REFERENCES " + TABLE_BOOKS + "(" + COLUMN_ISBN + ")"
            + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Creating required tables
        db.execSQL(CREATE_TABLE_ADMINS);
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_BOOKS);
        db.execSQL(CREATE_TABLE_BORROW_RECORDS);

        Log.d(TAG, "Database created successfully");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BORROW_RECORDS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ADMINS);

        // Create tables again
        onCreate(db);

        Log.d(TAG, "Database upgraded from version " + oldVersion + " to " + newVersion);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }

    // ==================== ADMIN OPERATIONS ====================

    public long addAdmin(String fullName, String adminId, String email, String password, String nfcTagId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FULL_NAME, fullName);
        values.put(COLUMN_ADMIN_ID, adminId);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password); // Note: In production, hash this password!
        values.put(COLUMN_NFC_TAG_ID, nfcTagId);

        long result = db.insert(TABLE_ADMINS, null, values);
        db.close();

        Log.d(TAG, "Admin added with result: " + result);
        return result;
    }

    public boolean checkAdminExists(String adminId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ADMINS,
                new String[]{COLUMN_ID},
                COLUMN_ADMIN_ID + " = ?",
                new String[]{adminId},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean checkEmailExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ADMINS,
                new String[]{COLUMN_ID},
                COLUMN_EMAIL + " = ?",
                new String[]{email},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean checkNfcTagExists(String nfcTagId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ADMINS,
                new String[]{COLUMN_ID},
                COLUMN_NFC_TAG_ID + " = ?",
                new String[]{nfcTagId},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean validateAdminLogin(String adminId, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ADMINS,
                new String[]{COLUMN_ID},
                COLUMN_ADMIN_ID + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{adminId, password},
                null, null, null);
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    public Cursor getAdminByNfcTag(String nfcTagId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ADMINS,
                new String[]{COLUMN_ID, COLUMN_FULL_NAME, COLUMN_ADMIN_ID, COLUMN_EMAIL},
                COLUMN_NFC_TAG_ID + " = ?",
                new String[]{nfcTagId},
                null, null, null);
    }

    // ==================== USER OPERATIONS ====================

    public long addUser(String userId, String fullName, String email, String phone, String nfcTagId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_USER_FULL_NAME, fullName);
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_USER_PHONE, phone);
        values.put(COLUMN_USER_NFC_TAG_ID, nfcTagId);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        Log.d(TAG, "User added with result: " + result);
        return result;
    }

    public boolean checkUserExists(String userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID},
                COLUMN_USER_ID + " = ?",
                new String[]{userId},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean checkUserNfcExists(String nfcTagId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID},
                COLUMN_USER_NFC_TAG_ID + " = ?",
                new String[]{nfcTagId},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public Cursor getUserByNfcTag(String nfcTagId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_USERS,
                new String[]{COLUMN_ID, COLUMN_USER_ID, COLUMN_USER_FULL_NAME, COLUMN_USER_EMAIL, COLUMN_USER_PHONE},
                COLUMN_USER_NFC_TAG_ID + " = ?",
                new String[]{nfcTagId},
                null, null, null);
    }

    public Cursor getAllUsers() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_USERS,
                new String[]{COLUMN_ID, COLUMN_USER_ID, COLUMN_USER_FULL_NAME, COLUMN_USER_EMAIL, COLUMN_USER_PHONE, COLUMN_USER_NFC_TAG_ID, COLUMN_CREATED_AT},
                null, null, null, null, COLUMN_CREATED_AT + " DESC");
    }

    // ==================== BOOK OPERATIONS ====================

    public long addBook(String bookId, String title, String author, String isbn, String publisher,
                        int year, String genre, String description, int quantity, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_BOOK_ID, bookId);
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_AUTHOR, author);
        values.put(COLUMN_ISBN, isbn);
        values.put(COLUMN_PUBLISHER, publisher);
        values.put(COLUMN_YEAR, year);
        values.put(COLUMN_GENRE, genre);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_QUANTITY, quantity);
        values.put(COLUMN_AVAILABLE, quantity);
        values.put(COLUMN_LOCATION, location);

        long result = db.insert(TABLE_BOOKS, null, values);
        db.close();

        Log.d(TAG, "Book added with result: " + result);
        return result;
    }

    public boolean checkBookExists(String isbn) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_BOOKS,
                new String[]{COLUMN_ID},
                COLUMN_ISBN + " = ?",
                new String[]{isbn},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public Cursor getBookByIsbn(String isbn) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_BOOKS,
                new String[]{COLUMN_ID, COLUMN_BOOK_ID, COLUMN_TITLE, COLUMN_AUTHOR, COLUMN_ISBN,
                        COLUMN_PUBLISHER, COLUMN_YEAR, COLUMN_GENRE, COLUMN_DESCRIPTION,
                        COLUMN_QUANTITY, COLUMN_AVAILABLE, COLUMN_LOCATION},
                COLUMN_ISBN + " = ?",
                new String[]{isbn},
                null, null, null);
    }

    public Cursor getAllBooks() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_BOOKS,
                new String[]{COLUMN_ID, COLUMN_BOOK_ID, COLUMN_TITLE, COLUMN_AUTHOR, COLUMN_ISBN,
                        COLUMN_PUBLISHER, COLUMN_YEAR, COLUMN_GENRE, COLUMN_QUANTITY,
                        COLUMN_AVAILABLE, COLUMN_LOCATION},
                null, null, null, null, COLUMN_TITLE + " ASC");
    }

    public Cursor searchBooks(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_TITLE + " LIKE ? OR " + COLUMN_AUTHOR + " LIKE ? OR " + COLUMN_ISBN + " LIKE ? OR " + COLUMN_GENRE + " LIKE ?";
        String[] selectionArgs = new String[]{"%" + query + "%", "%" + query + "%", "%" + query + "%", "%" + query + "%"};

        return db.query(TABLE_BOOKS,
                new String[]{COLUMN_ID, COLUMN_BOOK_ID, COLUMN_TITLE, COLUMN_AUTHOR, COLUMN_ISBN,
                        COLUMN_PUBLISHER, COLUMN_YEAR, COLUMN_GENRE, COLUMN_QUANTITY,
                        COLUMN_AVAILABLE, COLUMN_LOCATION},
                selection, selectionArgs, null, null, COLUMN_TITLE + " ASC");
    }

    public int updateBookAvailability(String isbn, int change) {
        SQLiteDatabase db = this.getWritableDatabase();

        // First get current available count
        Cursor cursor = db.query(TABLE_BOOKS,
                new String[]{COLUMN_AVAILABLE},
                COLUMN_ISBN + " = ?",
                new String[]{isbn},
                null, null, null);

        int currentAvailable = 0;
        if (cursor.moveToFirst()) {
            currentAvailable = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_AVAILABLE));
        }
        cursor.close();

        int newAvailable = Math.max(0, currentAvailable + change);

        ContentValues values = new ContentValues();
        values.put(COLUMN_AVAILABLE, newAvailable);

        int rowsAffected = db.update(TABLE_BOOKS, values, COLUMN_ISBN + " = ?", new String[]{isbn});
        db.close();

        return rowsAffected;
    }

    // ==================== BORROW OPERATIONS ====================

    public long borrowBook(String borrowId, String userNfc, String bookIsbn, String dueDate) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Start transaction
        db.beginTransaction();
        try {
            // First, check if book is available
            Cursor bookCursor = db.query(TABLE_BOOKS,
                    new String[]{COLUMN_AVAILABLE, COLUMN_TITLE},
                    COLUMN_ISBN + " = ?",
                    new String[]{bookIsbn},
                    null, null, null);

            if (!bookCursor.moveToFirst()) {
                bookCursor.close();
                return -1; // Book not found
            }

            int available = bookCursor.getInt(bookCursor.getColumnIndexOrThrow(COLUMN_AVAILABLE));
            if (available <= 0) {
                bookCursor.close();
                return -2; // Book not available
            }
            bookCursor.close();

            // Insert borrow record
            ContentValues values = new ContentValues();
            values.put(COLUMN_BORROW_ID, borrowId);
            values.put(COLUMN_USER_NFC, userNfc);
            values.put(COLUMN_BOOK_ISBN, bookIsbn);
            values.put(COLUMN_DUE_DATE, dueDate);
            values.put(COLUMN_STATUS, "borrowed");

            long result = db.insert(TABLE_BORROW_RECORDS, null, values);

            if (result != -1) {
                // Update book availability
                ContentValues bookValues = new ContentValues();
                bookValues.put(COLUMN_AVAILABLE, available - 1);
                db.update(TABLE_BOOKS, bookValues, COLUMN_ISBN + " = ?", new String[]{bookIsbn});

                db.setTransactionSuccessful();
            }

            return result;
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    public long returnBook(String borrowId) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.beginTransaction();
        try {
            // Get borrow record details
            Cursor borrowCursor = db.query(TABLE_BORROW_RECORDS,
                    new String[]{COLUMN_BOOK_ISBN},
                    COLUMN_BORROW_ID + " = ?",
                    new String[]{borrowId},
                    null, null, null);

            if (!borrowCursor.moveToFirst()) {
                borrowCursor.close();
                return -1; // Borrow record not found
            }

            String bookIsbn = borrowCursor.getString(borrowCursor.getColumnIndexOrThrow(COLUMN_BOOK_ISBN));
            borrowCursor.close();

            // Update borrow record
            ContentValues values = new ContentValues();
            values.put(COLUMN_RETURN_DATE, "datetime('now')");
            values.put(COLUMN_STATUS, "returned");

            long result = db.update(TABLE_BORROW_RECORDS, values, COLUMN_BORROW_ID + " = ?", new String[]{borrowId});

            if (result > 0) {
                // Update book availability
                updateBookAvailability(bookIsbn, 1);
                db.setTransactionSuccessful();
            }

            return result;
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    public Cursor getBorrowRecordsByUser(String userNfc) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT br.*, b." + COLUMN_TITLE + ", b." + COLUMN_AUTHOR +
                " FROM " + TABLE_BORROW_RECORDS + " br" +
                " INNER JOIN " + TABLE_BOOKS + " b ON br." + COLUMN_BOOK_ISBN + " = b." + COLUMN_ISBN +
                " WHERE br." + COLUMN_USER_NFC + " = ?" +
                " ORDER BY br." + COLUMN_BORROW_DATE + " DESC";

        return db.rawQuery(query, new String[]{userNfc});
    }

    public Cursor getActiveBorrowRecords() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_BORROW_RECORDS,
                new String[]{COLUMN_ID, COLUMN_BORROW_ID, COLUMN_USER_NFC, COLUMN_BOOK_ISBN,
                        COLUMN_BORROW_DATE, COLUMN_DUE_DATE, COLUMN_STATUS},
                COLUMN_STATUS + " = ?",
                new String[]{"borrowed"},
                null, null, COLUMN_DUE_DATE + " ASC");
    }

    // ==================== STATISTICS OPERATIONS ====================

    public int getTotalBooksCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_BOOKS, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getTotalUsersCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_USERS, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getBorrowedBooksCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_BORROW_RECORDS + " WHERE " + COLUMN_STATUS + " = 'borrowed'", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getOverdueBooksCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_BORROW_RECORDS +
                " WHERE " + COLUMN_STATUS + " = 'borrowed' AND " + COLUMN_DUE_DATE + " < date('now')", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    // ==================== UTILITY METHODS ====================

    public void deleteAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_BORROW_RECORDS, null, null);
        db.delete(TABLE_BOOKS, null, null);
        db.delete(TABLE_USERS, null, null);
        db.delete(TABLE_ADMINS, null, null);
        db.close();

        Log.d(TAG, "All data deleted from database");
    }

    public boolean isDatabaseEmpty() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_ADMINS, null);
        boolean isEmpty = true;
        if (cursor.moveToFirst()) {
            isEmpty = cursor.getInt(0) == 0;
        }
        cursor.close();
        return isEmpty;
    }
}