package com.example.incredibookv2;

import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import java.nio.charset.StandardCharsets;

public class NfcUtils {

    public static NdefMessage createNdefMessage(String mimeType, byte[] payload) {
        try {
            byte[] mimeBytes = mimeType.getBytes(StandardCharsets.US_ASCII);
            NdefRecord record = new NdefRecord(
                    NdefRecord.TNF_MIME_MEDIA,
                    mimeBytes,
                    new byte[0],
                    payload
            );
            return new NdefMessage(new NdefRecord[]{record});
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static NdefRecord createTextRecord(String text) {
        try {
            byte[] langBytes = "en".getBytes(StandardCharsets.US_ASCII);
            byte[] textBytes = text.getBytes(StandardCharsets.UTF_8);
            byte[] payload = new byte[1 + langBytes.length + textBytes.length];

            payload[0] = (byte) langBytes.length;
            System.arraycopy(langBytes, 0, payload, 1, langBytes.length);
            System.arraycopy(textBytes, 0, payload, 1 + langBytes.length, textBytes.length);

            return new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, new byte[0], payload);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}