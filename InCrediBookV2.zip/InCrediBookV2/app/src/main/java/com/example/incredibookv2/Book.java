package com.example.incredibookv2;

public class Book {
    private String id;
    private String title;
    private String author;
    private String isbn;
    private String category;
    private String description;
    private String cover_image; // Changed to match Supabase column name
    private boolean available;
    private int total_copies; // Changed to match Supabase column name
    private int available_copies; // Changed to match Supabase column name

    public Book() {
        // Default constructor
    }

    // Getters and Setters that match Supabase column names
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    // Updated getter and setter for cover_image
    public String getCoverImage() { return cover_image; }
    public void setCoverImage(String coverImage) { this.cover_image = coverImage; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    // Updated getter and setter for total_copies
    public int getTotalCopies() { return total_copies; }
    public void setTotalCopies(int totalCopies) { this.total_copies = totalCopies; }

    // Updated getter and setter for available_copies
    public int getAvailableCopies() { return available_copies; }
    public void setAvailableCopies(int availableCopies) { this.available_copies = availableCopies; }
}