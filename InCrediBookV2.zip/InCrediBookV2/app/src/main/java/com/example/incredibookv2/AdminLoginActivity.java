package com.example.incredibookv2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AdminLoginActivity extends AppCompatActivity {

    private EditText editTextAdminId, editTextAdminPassword;
    private Button buttonAdminLogin, adminRegisterWithNFC;
    private TextView textViewRegister, textViewNFCLogin;
    private SharedPreferences sharedPreferences;
    private AdminAuthService adminAuthService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        initializeViews();
        setupClickListeners();

        sharedPreferences = getSharedPreferences("InCrediBookPrefs", MODE_PRIVATE);
        adminAuthService = new AdminAuthService(this);

        // Check if admin is already logged in
        if (sharedPreferences.getBoolean("isAdminLoggedIn", false)) {
            startActivity(new Intent(this, AdminActivity.class));
            finish();
        }
    }

    private void initializeViews() {
        editTextAdminId = findViewById(R.id.editTextAdminId);
        editTextAdminPassword = findViewById(R.id.editTextAdminPassword);
        buttonAdminLogin = findViewById(R.id.buttonAdminLogin);
        adminRegisterWithNFC = findViewById(R.id.adminRegisterWithNFC);
        textViewRegister = findViewById(R.id.textViewRegister);
        textViewNFCLogin = findViewById(R.id.textViewNFCLogin);
    }

    private void setupClickListeners() {
        buttonAdminLogin.setOnClickListener(v -> handleAdminLogin());
        textViewRegister.setOnClickListener(v -> switchToAdminRegister());
        adminRegisterWithNFC.setOnClickListener(v -> switchToNFCRegistration());
        textViewNFCLogin.setOnClickListener(v -> switchToNFCLogin());
    }

    private void handleAdminLogin() {
        String adminId = editTextAdminId.getText().toString().trim();
        String password = editTextAdminPassword.getText().toString().trim();

        if (adminId.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter Admin ID and Password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Disable button during login attempt
        buttonAdminLogin.setEnabled(false);
        buttonAdminLogin.setText("Logging In...");

        adminAuthService.loginAdmin(adminId, password, new SupabaseService.LoginCallback() {
            @Override
            public void onResult(Admin admin) {
                runOnUiThread(() -> {
                    buttonAdminLogin.setEnabled(true);
                    buttonAdminLogin.setText("Login");

                    if (admin != null) {
                        Toast.makeText(AdminLoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                        saveAdminDetails(admin);
                        //checkAndUpdateNFCStatus(admin);
                        Intent intent = new Intent(AdminLoginActivity.this, AdminActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(AdminLoginActivity.this, "Invalid Admin ID or Password.", Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    buttonAdminLogin.setEnabled(true);
                    buttonAdminLogin.setText("Login");

                    Toast.makeText(AdminLoginActivity.this,
                            "Login failed: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void saveAdminDetails(Admin admin) {
        // Robust Full Name Check
        String fullName = admin.getFullName();
        if (fullName == null || fullName.trim().isEmpty()) {
            fullName = admin.getAdminId();
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isAdminLoggedIn", true);
        editor.putString("adminId", admin.getAdminId());
        editor.putString("adminFullName", fullName);
        editor.putString("adminEmail", admin.getEmail());
        editor.apply();
    }

//    private void checkAndUpdateNFCStatus(Admin admin) {
//        // Check if this admin has NFC registered
//        if (admin.getNfcUid() != null && !admin.getNfcUid().isEmpty()) {
//            SharedPreferences.Editor editor = sharedPreferences.edit();
//            editor.putBoolean("hasNFCRegistered", true);
//            editor.putString("nfcUid", admin.getNfcUid());
//            editor.apply();
//        } else {
//            SharedPreferences.Editor editor = sharedPreferences.edit();
//            editor.putBoolean("hasNFCRegistered", false);
//            editor.remove("nfcUid");
//            editor.apply();
//        }
//    }

    private void switchToAdminRegister() {
        Intent intent = new Intent(this, AdminRegisterActivity.class);
        startActivity(intent);
        finish();
    }

    private void switchToNFCRegistration() {
        Intent intent = new Intent(this, AdminNFCRegisterActivity.class);
        startActivity(intent);
        finish();
    }

    private void switchToNFCLogin() {
        Intent intent = new Intent(this, NFCLoginActivity.class);
        startActivity(intent);
        finish();
    }
}