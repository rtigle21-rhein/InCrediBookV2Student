package com.example.incredibookv2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class AdminActivity extends AppCompatActivity {

    private TextView textViewWelcome;
    private CardView cardBookManagement, cardStudentManagement, cardBorrowReports, cardPendingRequests;
    private Button btnDashboard, btnBooks, btnStudents, btnReports, btnLogout;
    private SharedPreferences sharedPreferences;
    private View mainContent;
    private View adminContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        initializeViews();
        setupClickListeners();
        setupButtonNavigation();

        sharedPreferences = getSharedPreferences("InCrediBookPrefs", MODE_PRIVATE);
        String adminId = sharedPreferences.getString("adminId", "Admin");
        String adminFullName = sharedPreferences.getString("adminFullName", "");

        // Display welcome message with full name if available
        if (!adminFullName.isEmpty() && !adminFullName.equals(adminId)) {
            textViewWelcome.setText("Welcome, " + adminFullName + "!");
        } else {
            textViewWelcome.setText("Welcome, " + adminId + "!");
        }
    }

    private void initializeViews() {
        textViewWelcome = findViewById(R.id.textViewWelcome);
        cardBookManagement = findViewById(R.id.cardBookManagement);
        cardStudentManagement = findViewById(R.id.cardStudentManagement);
        cardBorrowReports = findViewById(R.id.cardBorrowReports);
        cardPendingRequests = findViewById(R.id.cardPendingRequests);

        // Button navigation
        btnDashboard = findViewById(R.id.btnDashboard);
        btnBooks = findViewById(R.id.btnBooks);
        btnStudents = findViewById(R.id.btnStudents);
        btnReports = findViewById(R.id.btnReports);
        btnLogout = findViewById(R.id.btnLogout);

        // Fragment containers
        mainContent = findViewById(R.id.mainContent);
        adminContainer = findViewById(R.id.adminContainer);
    }

    private void setupClickListeners() {
        cardBookManagement.setOnClickListener(v -> {
            showFragment(new BookManagementFragment());
            setActiveButton(btnBooks);
        });

        cardStudentManagement.setOnClickListener(v -> {
            Toast.makeText(this, "Student Management Selected", Toast.LENGTH_SHORT).show();
            // TODO: Implement Student Management Fragment
        });

        cardBorrowReports.setOnClickListener(v -> {
            Toast.makeText(this, "Borrowing Reports Selected", Toast.LENGTH_SHORT).show();
            // TODO: Implement Borrowing Reports Fragment
        });

        cardPendingRequests.setOnClickListener(v -> {
            Toast.makeText(this, "Pending Requests Selected", Toast.LENGTH_SHORT).show();
            // TODO: Implement Pending Requests Fragment
        });
    }

    private void setupButtonNavigation() {
        // Set dashboard as active by default
        setActiveButton(btnDashboard);

        btnDashboard.setOnClickListener(v -> {
            setActiveButton(btnDashboard);
            hideFragment();
        });

        btnBooks.setOnClickListener(v -> {
            setActiveButton(btnBooks);
            showFragment(new BookManagementFragment());
        });

        btnStudents.setOnClickListener(v -> {
            setActiveButton(btnStudents);
            Toast.makeText(this, "Students Management", Toast.LENGTH_SHORT).show();
            // TODO: Implement Student Management Fragment
        });

        btnReports.setOnClickListener(v -> {
            setActiveButton(btnReports);
            Toast.makeText(this, "Reports & Analytics", Toast.LENGTH_SHORT).show();
            // TODO: Implement Reports Fragment
        });

        btnLogout.setOnClickListener(v -> {
            logout();
        });
    }

    private void showFragment(Fragment fragment) {
        // Hide main content
        mainContent.setVisibility(View.GONE);

        // Show fragment container
        adminContainer.setVisibility(View.VISIBLE);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.adminContainer, fragment)
                .addToBackStack("fragment_stack")
                .commit();
    }

    private void hideFragment() {
        // Show main content
        mainContent.setVisibility(View.VISIBLE);

        // Hide fragment container
        adminContainer.setVisibility(View.GONE);

        // Clear back stack
        getSupportFragmentManager().popBackStack("fragment_stack", FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }

    private void setActiveButton(Button activeButton) {
        // Reset all buttons to inactive state
        btnDashboard.setTextColor(getResources().getColor(R.color.gray));
        btnDashboard.setCompoundDrawableTintList(ColorStateList.valueOf(getResources().getColor(R.color.gray)));

        btnBooks.setTextColor(getResources().getColor(R.color.gray));
        btnBooks.setCompoundDrawableTintList(ColorStateList.valueOf(getResources().getColor(R.color.gray)));

        btnStudents.setTextColor(getResources().getColor(R.color.gray));
        btnStudents.setCompoundDrawableTintList(ColorStateList.valueOf(getResources().getColor(R.color.gray)));

        btnReports.setTextColor(getResources().getColor(R.color.gray));
        btnReports.setCompoundDrawableTintList(ColorStateList.valueOf(getResources().getColor(R.color.gray)));

        btnLogout.setTextColor(getResources().getColor(R.color.gray));
        btnLogout.setCompoundDrawableTintList(ColorStateList.valueOf(getResources().getColor(R.color.gray)));

        // Set active button
        activeButton.setTextColor(getResources().getColor(R.color.primary));
        activeButton.setCompoundDrawableTintList(ColorStateList.valueOf(getResources().getColor(R.color.primary)));
    }

    private void logout() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isAdminLoggedIn", false);
        editor.remove("adminId");
        editor.remove("adminFullName");
        editor.remove("adminEmail");
        editor.remove("hasNFCRegistered");
        editor.remove("nfcUid");
        editor.apply();

        Intent intent = new Intent(this, AdminLoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (adminContainer.getVisibility() == View.VISIBLE) {
            hideFragment();
            setActiveButton(btnDashboard);
        } else {
            moveTaskToBack(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // If we're coming back from another activity and fragment was visible, restore it
        if (adminContainer.getVisibility() == View.VISIBLE) {
            // Check if we need to refresh the fragment data
            Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.adminContainer);
            if (currentFragment instanceof BookManagementFragment) {
                // You can add refresh logic here if needed
            }
        }
    }
}