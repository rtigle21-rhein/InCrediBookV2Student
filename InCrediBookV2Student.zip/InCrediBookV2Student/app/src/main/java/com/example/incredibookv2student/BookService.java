package com.example.incredibookv2student;

import android.util.Log;
import java.util.List;

public class BookService {
    private static final String TAG = "BookService";
    private SupabaseBookService supabaseBookService;

    public BookService() {
        this.supabaseBookService = new SupabaseBookService();
    }

    public void getRecentBooks(BooksCallback callback) {
        Log.d(TAG, "Fetching recent books from database");
        supabaseBookService.getRecentBooks(callback);
    }

    public void getAllBooks(BooksCallback callback) {
        Log.d(TAG, "Fetching all books from database");
        supabaseBookService.getAllBooks(callback);
    }

    public interface BooksCallback {
        void onResult(List<Book> books);
        void onError(String error);
    }
}