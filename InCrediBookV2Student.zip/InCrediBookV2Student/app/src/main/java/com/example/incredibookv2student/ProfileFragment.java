package com.example.incredibookv2student;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.textfield.TextInputLayout;
import java.util.HashMap;
import java.util.Map;

public class ProfileFragment extends Fragment {

    private EditText editTextFirstName, editTextLastName, editTextMiddleName,
            editTextEmail, editTextAddress, editTextPhone, editTextSchool,
            editTextAge, editTextGender, editTextPassword, editTextConfirmPassword;
    private Button buttonUpdate, buttonLogout;
    private SharedPreferences sharedPreferences;
    private UserAuthService userAuthService;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        sharedPreferences = requireActivity().getSharedPreferences("InCrediBookPrefs", 0);
        userAuthService = new UserAuthService(requireContext());
        initializeViews(view);
        setupClickListeners();
        loadUserData();

        return view;
    }

    private void initializeViews(View view) {
        editTextFirstName = view.findViewById(R.id.editTextFirstName);
        editTextLastName = view.findViewById(R.id.editTextLastName);
        editTextMiddleName = view.findViewById(R.id.editTextMiddleName);
        editTextEmail = view.findViewById(R.id.editTextEmail);
        editTextAddress = view.findViewById(R.id.editTextAddress);
        editTextPhone = view.findViewById(R.id.editTextPhone);
        editTextSchool = view.findViewById(R.id.editTextSchool);
        editTextAge = view.findViewById(R.id.editTextAge);
        editTextGender = view.findViewById(R.id.editTextGender);
        editTextPassword = view.findViewById(R.id.editTextPassword);
        editTextConfirmPassword = view.findViewById(R.id.editTextConfirmPassword);
        buttonUpdate = view.findViewById(R.id.buttonUpdate);
        buttonLogout = view.findViewById(R.id.buttonLogout);
    }

    private void setupClickListeners() {
        buttonUpdate.setOnClickListener(v -> updateProfile());
        buttonLogout.setOnClickListener(v -> logout());
    }

    private void loadUserData() {
        editTextFirstName.setText(sharedPreferences.getString("userFirstName", ""));
        editTextLastName.setText(sharedPreferences.getString("userLastName", ""));
        editTextMiddleName.setText(sharedPreferences.getString("userMiddleName", ""));
        editTextEmail.setText(sharedPreferences.getString("userEmail", ""));
        editTextAddress.setText(sharedPreferences.getString("userAddress", ""));
        editTextPhone.setText(sharedPreferences.getString("userPhone", ""));
        editTextSchool.setText(sharedPreferences.getString("userSchool", ""));
        editTextAge.setText(sharedPreferences.getString("userAge", ""));
        editTextGender.setText(sharedPreferences.getString("userGender", ""));
    }

    private void updateProfile() {
        if (!validateInput()) {
            return;
        }

        Map<String, String> updates = new HashMap<>();
        updates.put("first_name", editTextFirstName.getText().toString().trim());
        updates.put("last_name", editTextLastName.getText().toString().trim());
        updates.put("middle_name", editTextMiddleName.getText().toString().trim());
        updates.put("email", editTextEmail.getText().toString().trim());
        updates.put("address", editTextAddress.getText().toString().trim());
        updates.put("phone_number", editTextPhone.getText().toString().trim());
        updates.put("school", editTextSchool.getText().toString().trim());
        updates.put("age", editTextAge.getText().toString().trim());
        updates.put("gender", editTextGender.getText().toString().trim());

        String password = editTextPassword.getText().toString().trim();
        if (!password.isEmpty()) {
            updates.put("password_hash", password);
        }

        // TODO: Implement API call to update user profile
        updateUserProfile(updates);
    }

    private boolean validateInput() {
        if (editTextFirstName.getText().toString().trim().isEmpty()) {
            showError("First name is required");
            return false;
        }
        if (editTextLastName.getText().toString().trim().isEmpty()) {
            showError("Last name is required");
            return false;
        }
        if (editTextEmail.getText().toString().trim().isEmpty()) {
            showError("Email is required");
            return false;
        }

        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();

        if (!password.isEmpty() && !password.equals(confirmPassword)) {
            showError("Passwords do not match");
            return false;
        }

        return true;
    }

    private void updateUserProfile(Map<String, String> updates) {
        // TODO: Implement API call to update user in Supabase
        // For now, update SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();

        for (Map.Entry<String, String> entry : updates.entrySet()) {
            switch (entry.getKey()) {
                case "first_name":
                    editor.putString("userFirstName", entry.getValue());
                    break;
                case "last_name":
                    editor.putString("userLastName", entry.getValue());
                    break;
                case "middle_name":
                    editor.putString("userMiddleName", entry.getValue());
                    break;
                case "email":
                    editor.putString("userEmail", entry.getValue());
                    break;
                case "address":
                    editor.putString("userAddress", entry.getValue());
                    break;
                case "phone_number":
                    editor.putString("userPhone", entry.getValue());
                    break;
                case "school":
                    editor.putString("userSchool", entry.getValue());
                    break;
                case "age":
                    editor.putString("userAge", entry.getValue());
                    break;
                case "gender":
                    editor.putString("userGender", entry.getValue());
                    break;
            }
        }

        // Update full name
        String fullName = updates.get("first_name") + " " +
                (updates.get("middle_name") != null && !updates.get("middle_name").isEmpty() ?
                        updates.get("middle_name") + " " : "") +
                updates.get("last_name");
        editor.putString("userFullName", fullName);

        editor.apply();

        Toast.makeText(getContext(), "Profile updated successfully", Toast.LENGTH_SHORT).show();

        // Clear password fields
        editTextPassword.getText().clear();
        editTextConfirmPassword.getText().clear();
    }

    private void showError(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void logout() {
        if (getActivity() instanceof UserDashboardActivity) {
            ((UserDashboardActivity) getActivity()).handleLogout();
        }
    }
}