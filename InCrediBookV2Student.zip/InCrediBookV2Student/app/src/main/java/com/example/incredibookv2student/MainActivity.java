package com.example.incredibookv2student;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences("InCrediBookPrefs", MODE_PRIVATE);

        initializeViews();
        setupClickListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Check if user is already logged in when activity resumes
        checkExistingLogin();
    }

    private void initializeViews() {
        Button buttonUserLogin = findViewById(R.id.buttonUserLogin);
        Button buttonAdminLogin = findViewById(R.id.buttonAdminLogin);

        // You can add any additional view initialization here if needed
    }

    private void setupClickListeners() {
        Button buttonUserLogin = findViewById(R.id.buttonUserLogin);
        Button buttonAdminLogin = findViewById(R.id.buttonAdminLogin);

        buttonUserLogin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UserLoginActivity.class);
            startActivity(intent);
        });

        buttonAdminLogin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UserLoginActivity.class);
            startActivity(intent);
        });
    }

    private void checkExistingLogin() {
        boolean isUserLoggedIn = sharedPreferences.getBoolean("isUserLoggedIn", false);
        boolean isAdminLoggedIn = sharedPreferences.getBoolean("isAdminLoggedIn", false);

        if (isUserLoggedIn) {
            // User is logged in, redirect to User Dashboard
            Intent intent = new Intent(this, UserDashboardActivity.class);
            startActivity(intent);
            finish(); // Close MainActivity so user can't go back with back button
        } else if (isAdminLoggedIn) {
            // Admin is logged in, redirect to Admin Dashboard
            Intent intent = new Intent(this, UserDashboardActivity.class);
            startActivity(intent);
            finish(); // Close MainActivity so admin can't go back with back button
        }
        // If neither is logged in, stay on MainActivity for user to choose login type
    }

    @Override
    public void onBackPressed() {
        // Optional: You can customize back button behavior
        // For example, exit the app when back button is pressed on MainActivity
        super.onBackPressed();
        finishAffinity(); // This will close the app completely
    }
}