package com.example.incredibookv2student;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class BookDetailsDialog extends DialogFragment {

    private static final String ARG_BOOK = "book";
    private Book book;
    private TextView textTitle, textAuthor, textIsbn, textCategory, textDescription,
            textAvailableCopies, textReturnDate;
    private Button buttonRequest;

    public static BookDetailsDialog newInstance(Book book) {
        BookDetailsDialog fragment = new BookDetailsDialog();
        Bundle args = new Bundle();
        args.putSerializable(ARG_BOOK, book);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            book = (Book) getArguments().getSerializable(ARG_BOOK);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_book_details, null);

        initializeViews(view);
        populateBookDetails();
        setupClickListeners();

        builder.setView(view)
                .setNegativeButton("Close", (dialog, id) -> dismiss());

        return builder.create();
    }

    private void initializeViews(View view) {
        textTitle = view.findViewById(R.id.textTitle);
        textAuthor = view.findViewById(R.id.textAuthor);
        textIsbn = view.findViewById(R.id.textIsbn);
        textCategory = view.findViewById(R.id.textCategory);
        textDescription = view.findViewById(R.id.textDescription);
        textAvailableCopies = view.findViewById(R.id.textAvailableCopies);
        textReturnDate = view.findViewById(R.id.textReturnDate);
        buttonRequest = view.findViewById(R.id.buttonRequest);
    }

    private void populateBookDetails() {
        if (book != null) {
            textTitle.setText(book.getTitle());
            textAuthor.setText("By: " + book.getAuthor());
            textIsbn.setText("ISBN: " + (book.getIsbn() != null ? book.getIsbn() : "N/A"));
            textCategory.setText("Category: " + (book.getCategory() != null ? book.getCategory() : "General"));
            textDescription.setText(book.getDescription() != null ? book.getDescription() : "No description available.");

            String availability = book.getAvailableCopies() + " copies available";
            textAvailableCopies.setText(availability);

            // Calculate return date (14 days from now)
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DAY_OF_YEAR, 14);
            SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault());
            String returnDate = "Return by: " + sdf.format(calendar.getTime());
            textReturnDate.setText(returnDate);

            // Enable/disable request button based on availability
            buttonRequest.setEnabled(book.getAvailableCopies() > 0);
            if (book.getAvailableCopies() == 0) {
                buttonRequest.setText("Out of Stock");
                buttonRequest.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
            }
        }
    }

    private void setupClickListeners() {
        buttonRequest.setOnClickListener(v -> requestBook());
    }

    private void requestBook() {
        if (book == null || book.getAvailableCopies() <= 0) {
            Toast.makeText(getContext(), "Book is not available for borrowing", Toast.LENGTH_SHORT).show();
            return;
        }

        // TODO: Implement book request API call
        // Check wallet balance, process payment, create borrowing record

        double borrowingFee = 10.0; // Example fee
        Toast.makeText(getContext(),
                "Book requested successfully! ₱" + borrowingFee + " will be deducted from your wallet.",
                Toast.LENGTH_LONG).show();

        dismiss();
    }
}