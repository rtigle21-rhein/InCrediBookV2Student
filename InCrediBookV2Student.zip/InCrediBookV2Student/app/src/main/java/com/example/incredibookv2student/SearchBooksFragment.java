package com.example.incredibookv2student;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class SearchBooksFragment extends Fragment {

    private EditText editTextSearch;
    private Spinner spinnerCategory, spinnerSort;
    private RecyclerView recyclerViewBooks;
    private BookAdapter bookAdapter;
    private List<Book> allBooks;
    private List<Book> filteredBooks;
    private BookService bookService;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search_books, container, false);

        initializeViews(view);
        setupSpinners();
        setupRecyclerView();
        setupSearchListener();
        loadAllBooks();

        return view;
    }

    private void initializeViews(View view) {
        editTextSearch = view.findViewById(R.id.editTextSearch);
        spinnerCategory = view.findViewById(R.id.spinnerCategory);
        spinnerSort = view.findViewById(R.id.spinnerSort);
        recyclerViewBooks = view.findViewById(R.id.recyclerViewBooks);

        bookService = new BookService();
    }

    private void setupSpinners() {
        // Categories
        String[] categories = {"All Categories", "Fiction", "Non-Fiction", "Science", "Technology", "History", "Biography", "Computer Science", "Artificial Intelligence"};
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(categoryAdapter);

        // Sort options
        String[] sortOptions = {"A-Z", "Z-A", "Available Copies", "Newest"};
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, sortOptions);
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSort.setAdapter(sortAdapter);

        // Add listeners for spinners
        spinnerCategory.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                applyFilters();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        spinnerSort.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                applySorting();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    private void setupRecyclerView() {
        allBooks = new ArrayList<>();
        filteredBooks = new ArrayList<>();
        bookAdapter = new BookAdapter(filteredBooks, new BookAdapter.OnBookClickListener() {
            @Override
            public void onBookClick(Book book) {
                showBookDetails(book);
            }

            @Override
            public void onBookLongClick(Book book) {
                // Handle long click if needed
            }
        });

        recyclerViewBooks.setLayoutManager(new GridLayoutManager(getContext(), 2));
        recyclerViewBooks.setAdapter(bookAdapter);
    }

    private void setupSearchListener() {
        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilters();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void loadAllBooks() {
        // Show loading state
        Toast.makeText(requireContext(), "Loading books...", Toast.LENGTH_SHORT).show();

        bookService.getAllBooks(new BookService.BooksCallback() {
            @Override
            public void onResult(List<Book> books) {
                requireActivity().runOnUiThread(() -> {
                    allBooks.clear();
                    if (books != null && !books.isEmpty()) {
                        allBooks.addAll(books);
                        filteredBooks.clear();
                        filteredBooks.addAll(allBooks);
                        bookAdapter.notifyDataSetChanged();
                        Toast.makeText(requireContext(), "Loaded " + books.size() + " books", Toast.LENGTH_SHORT).show();
                    } else {
                        // Fallback to mock data if no books found
                        loadMockBooks();
                        Toast.makeText(requireContext(), "Using sample data", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> {
                    Log.e("SearchBooks", "Failed to load books: " + error);
                    // Fallback to mock data on error
                    loadMockBooks();
                    Toast.makeText(requireContext(), "Using offline data", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void loadMockBooks() {
        allBooks.clear();

        Book book1 = new Book();
        book1.setId("1");
        book1.setTitle("Android Development Guide");
        book1.setAuthor("John Developer");
        book1.setCategory("Technology");
        book1.setDescription("Complete guide to Android development with modern practices.");
        book1.setAvailableCopies(3);
        book1.setCoverImage("");

        Book book2 = new Book();
        book2.setId("2");
        book2.setTitle("Data Structures");
        book2.setAuthor("Jane Programmer");
        book2.setCategory("Computer Science");
        book2.setDescription("Comprehensive guide to data structures and algorithms.");
        book2.setAvailableCopies(5);
        book2.setCoverImage("");

        Book book3 = new Book();
        book3.setId("3");
        book3.setTitle("Machine Learning Basics");
        book3.setAuthor("AI Expert");
        book3.setCategory("Artificial Intelligence");
        book3.setDescription("Introduction to machine learning concepts and applications.");
        book3.setAvailableCopies(0);
        book3.setCoverImage("");

        Book book4 = new Book();
        book4.setId("4");
        book4.setTitle("Web Development");
        book4.setAuthor("Web Master");
        book4.setCategory("Technology");
        book4.setDescription("Modern web development techniques and frameworks.");
        book4.setAvailableCopies(2);
        book4.setCoverImage("");

        allBooks.add(book1);
        allBooks.add(book2);
        allBooks.add(book3);
        allBooks.add(book4);

        filteredBooks.clear();
        filteredBooks.addAll(allBooks);
        bookAdapter.notifyDataSetChanged();
    }

    private void applyFilters() {
        String query = editTextSearch.getText().toString().toLowerCase().trim();
        String selectedCategory = spinnerCategory.getSelectedItem().toString();

        filteredBooks.clear();

        for (Book book : allBooks) {
            boolean matchesSearch = query.isEmpty() ||
                    book.getTitle().toLowerCase().contains(query) ||
                    (book.getAuthor() != null && book.getAuthor().toLowerCase().contains(query)) ||
                    (book.getDescription() != null && book.getDescription().toLowerCase().contains(query));

            boolean matchesCategory = selectedCategory.equals("All Categories") ||
                    (book.getCategory() != null && selectedCategory.equals(book.getCategory()));

            if (matchesSearch && matchesCategory) {
                filteredBooks.add(book);
            }
        }

        applySorting();
    }

    private void applySorting() {
        String sortOption = spinnerSort.getSelectedItem().toString();

        switch (sortOption) {
            case "A-Z":
                filteredBooks.sort((b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));
                break;
            case "Z-A":
                filteredBooks.sort((b1, b2) -> b2.getTitle().compareToIgnoreCase(b1.getTitle()));
                break;
            case "Available Copies":
                filteredBooks.sort((b1, b2) -> Integer.compare(b2.getAvailableCopies(), b1.getAvailableCopies()));
                break;
            case "Newest":
                // Assuming newer books have higher IDs or later created_at dates
                // You might need to modify this based on your actual data structure
                filteredBooks.sort((b1, b2) -> b2.getId().compareTo(b1.getId()));
                break;
        }

        bookAdapter.notifyDataSetChanged();

        // Show message if no results
        if (filteredBooks.isEmpty()) {
            Toast.makeText(requireContext(), "No books found matching your criteria", Toast.LENGTH_SHORT).show();
        }
    }

    private void showBookDetails(Book book) {
        BookDetailsDialog dialog = BookDetailsDialog.newInstance(book);
        dialog.show(getParentFragmentManager(), "book_details");
    }

    // Method to refresh books (can be called from activity if needed)
    public void refreshBooks() {
        loadAllBooks();
    }
}