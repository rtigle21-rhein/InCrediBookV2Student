// UserNFCLoginActivity.java
package com.example.incredibookv2student;

import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

public class UserNFCLoginActivity extends AppCompatActivity implements NfcAdapter.ReaderCallback {

    private TextView textViewStatus;
    private Button buttonManualLogin;
    private NfcAdapter nfcAdapter;
    private SharedPreferences sharedPreferences;
    private UserAuthService userAuthService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_nfc_login);

        initializeViews();
        setupNFC();
        setupClickListeners();

        sharedPreferences = getSharedPreferences("InCrediBookPrefs", MODE_PRIVATE);
        userAuthService = new UserAuthService(this);

        // Check if user is already logged in
        if (sharedPreferences.getBoolean("isUserLoggedIn", false)) {
            startActivity(new Intent(this, UserDashboardActivity.class));
            finish();
        }
    }

    private void initializeViews() {
        textViewStatus = findViewById(R.id.textViewStatus);
        buttonManualLogin = findViewById(R.id.buttonManualLogin);
    }

    private void setupClickListeners() {
        buttonManualLogin.setOnClickListener(v -> switchToManualLogin());
    }

    private void setupNFC() {
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC is not available on this device.", Toast.LENGTH_LONG).show();
            textViewStatus.setText("NFC not available on this device");
        } else if (!nfcAdapter.isEnabled()) {
            Toast.makeText(this, "Please enable NFC to log in.", Toast.LENGTH_LONG).show();
            textViewStatus.setText("Please enable NFC");
        } else {
            textViewStatus.setText("Ready - Tap your NFC card to login");
        }
    }

    @Override
    public void onTagDiscovered(Tag tag) {
        String nfcTagId = bytesToHex(tag.getId());
        runOnUiThread(() -> {
            textViewStatus.setText("NFC Tag Discovered. Attempting login...");
            authenticateWithNFC(nfcTagId);
        });
    }

    private void authenticateWithNFC(final String nfcTagId) {
        userAuthService.loginUserWithNFC(nfcTagId, new SupabaseUserService.NFCLoginCallback() {
            @Override
            public void onResult(User user) {
                runOnUiThread(() -> {
                    if (user != null) {
                        textViewStatus.setText("User logged in via NFC.");
                        saveUserDetails(user);
                        Intent intent = new Intent(UserNFCLoginActivity.this, UserDashboardActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        textViewStatus.setText("Authentication failed. NFC card not registered or not found.");
                        Toast.makeText(UserNFCLoginActivity.this,
                                "NFC card not registered or not found", Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    textViewStatus.setText("Authentication failed. Tap again.");
                    Toast.makeText(UserNFCLoginActivity.this,
                            "NFC Login failed: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void saveUserDetails(User user) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isUserLoggedIn", true);
        editor.putString("userId", user.getId());
        editor.putString("userEmail", user.getEmail());

        // Save individual name fields to avoid null issues
        editor.putString("userFirstName", user.getFirstName() != null ? user.getFirstName() : "");
        editor.putString("userLastName", user.getLastName() != null ? user.getLastName() : "");
        editor.putString("userFullName", user.getFullName() != null ? user.getFullName() : "Student");

        editor.putString("userRole", user.getRole());
        editor.putString("studentId", user.getStudentId());
        editor.putBoolean("hasNFCRegistered", true);
        editor.putString("nfcTagId", user.getNfcTagId());
        editor.apply();

        Log.d("UserNFCLogin", "Saved user details - First: " + user.getFirstName() +
                ", Last: " + user.getLastName() + ", Full: " + user.getFullName());
    }

    // Convert byte array to hex string
    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    private void switchToManualLogin() {
        Intent intent = new Intent(this, UserLoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nfcAdapter != null && nfcAdapter.isEnabled()) {
            nfcAdapter.enableReaderMode(this, this,
                    NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK, null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) {
            nfcAdapter.disableReaderMode(this);
        }
    }
}