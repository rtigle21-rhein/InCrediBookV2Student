package com.example.incredibookv2student;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerViewRecentBooks;
    private BookAdapter bookAdapter;
    private TextView textViewWelcome, textViewStudentId;
    private List<Book> recentBooks;
    private SharedPreferences sharedPreferences;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        sharedPreferences = requireActivity().getSharedPreferences("InCrediBookPrefs", 0);
        initializeViews(view);
        setupRecyclerView();
        loadRecentBooks();
        displayUserWelcome();

        return view;
    }

    private void initializeViews(View view) {
        textViewWelcome = view.findViewById(R.id.textViewWelcome);
        textViewStudentId = view.findViewById(R.id.textViewStudentId);
        recyclerViewRecentBooks = view.findViewById(R.id.recyclerViewRecentBooks);
    }

    private void setupRecyclerView() {
        recentBooks = new ArrayList<>();
        bookAdapter = new BookAdapter(recentBooks, new BookAdapter.OnBookClickListener() {
            @Override
            public void onBookClick(Book book) {
                showBookDetails(book);
            }

            @Override
            public void onBookLongClick(Book book) {
                // Handle long click if needed
            }
        });

        recyclerViewRecentBooks.setLayoutManager(new GridLayoutManager(getContext(), 2));
        recyclerViewRecentBooks.setAdapter(bookAdapter);
    }

    private void loadRecentBooks() {
        BookService bookService = new BookService();
        bookService.getRecentBooks(new BookService.BooksCallback() {
            @Override
            public void onResult(List<Book> books) {
                requireActivity().runOnUiThread(() -> {
                    recentBooks.clear();
                    if (books != null && !books.isEmpty()) {
                        recentBooks.addAll(books);
                    } else {
                        // Fallback to mock data if no books found
                        loadMockBooks();
                    }
                    bookAdapter.notifyDataSetChanged();
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> {
                    Log.e("HomeFragment", "Failed to load books: " + error);
                    // Fallback to mock data on error
                    loadMockBooks();
                    Toast.makeText(getContext(), "Using offline data", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    // Add this missing method
    private void loadMockBooks() {
        recentBooks.clear();

        Book book1 = new Book();
        book1.setId("1");
        book1.setTitle("Android Development Guide");
        book1.setAuthor("John Developer");
        book1.setCategory("Technology");
        book1.setDescription("Complete guide to Android development with modern practices.");
        book1.setAvailableCopies(3);
        book1.setCoverImage("");

        Book book2 = new Book();
        book2.setId("2");
        book2.setTitle("Data Structures");
        book2.setAuthor("Jane Programmer");
        book2.setCategory("Computer Science");
        book2.setDescription("Comprehensive guide to data structures and algorithms.");
        book2.setAvailableCopies(5);
        book2.setCoverImage("");

        Book book3 = new Book();
        book3.setId("3");
        book3.setTitle("Machine Learning Basics");
        book3.setAuthor("AI Expert");
        book3.setCategory("Artificial Intelligence");
        book3.setDescription("Introduction to machine learning concepts and applications.");
        book3.setAvailableCopies(0);
        book3.setCoverImage("");

        Book book4 = new Book();
        book4.setId("4");
        book4.setTitle("Web Development");
        book4.setAuthor("Web Master");
        book4.setCategory("Technology");
        book4.setDescription("Modern web development techniques and frameworks.");
        book4.setAvailableCopies(2);
        book4.setCoverImage("");

        recentBooks.add(book1);
        recentBooks.add(book2);
        recentBooks.add(book3);
        recentBooks.add(book4);

        bookAdapter.notifyDataSetChanged();
    }

    private void displayUserWelcome() {
        String fullName = sharedPreferences.getString("userFullName", "");
        String firstName = sharedPreferences.getString("userFirstName", "");
        String lastName = sharedPreferences.getString("userLastName", "");
        String studentId = sharedPreferences.getString("studentId", "");

        // Fallback logic if fullName is null/empty
        if (fullName == null || fullName.isEmpty()) {
            if (!firstName.isEmpty() && !lastName.isEmpty()) {
                fullName = firstName + " " + lastName;
            } else if (!firstName.isEmpty()) {
                fullName = firstName;
            } else {
                fullName = "Student";
            }
        }

        textViewWelcome.setText("Welcome back, " + fullName + "!");
        textViewStudentId.setText("Student ID: " + (studentId.isEmpty() ? "Not set" : studentId));
    }

    private void showBookDetails(Book book) {
        BookDetailsDialog dialog = BookDetailsDialog.newInstance(book);
        dialog.show(getParentFragmentManager(), "book_details");
    }
}