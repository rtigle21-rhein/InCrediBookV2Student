package com.example.incredibookv2student;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CardWalletFragment extends Fragment {

    private TextView textViewBalance, textViewNfcStatus, textViewLastTopUp;
    private Button buttonTopUp;
    private SharedPreferences sharedPreferences;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_card_wallet, container, false);

        sharedPreferences = requireActivity().getSharedPreferences("InCrediBookPrefs", 0);
        initializeViews(view);
        setupClickListeners();
        loadWalletInfo();

        return view;
    }

    private void initializeViews(View view) {
        textViewBalance = view.findViewById(R.id.textViewBalance);
        textViewNfcStatus = view.findViewById(R.id.textViewNfcStatus);
        textViewLastTopUp = view.findViewById(R.id.textViewLastTopUp);
        buttonTopUp = view.findViewById(R.id.buttonTopUp);
    }

    private void setupClickListeners() {
        buttonTopUp.setOnClickListener(v -> showTopUpDialog());
    }

    private void loadWalletInfo() {
        // Load balance from SharedPreferences or API
        double balance = sharedPreferences.getFloat("walletBalance", 0.0f);
        boolean hasNFC = sharedPreferences.getBoolean("hasNFCRegistered", false);
        String lastTopUp = sharedPreferences.getString("lastTopUpDate", "Never");

        textViewBalance.setText(String.format("₱%.2f", balance));
        textViewNfcStatus.setText(hasNFC ? "NFC Card: Registered" : "NFC Card: Not Registered");
        textViewLastTopUp.setText("Last Top-up: " + lastTopUp);

        // Update button state based on NFC registration
        buttonTopUp.setEnabled(hasNFC);
    }

    private void showTopUpDialog() {
        TopUpDialog dialog = new TopUpDialog();
        dialog.setTopUpListener(amount -> {
            processTopUp(amount);
        });
        dialog.show(getParentFragmentManager(), "top_up_dialog");
    }

    private void processTopUp(double amount) {
        // TODO: Implement API call to process top-up
        // For now, update local storage

        double currentBalance = sharedPreferences.getFloat("walletBalance", 0.0f);
        double newBalance = currentBalance + amount;

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat("walletBalance", (float) newBalance);

        String currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
        editor.putString("lastTopUpDate", currentDate);

        editor.apply();

        loadWalletInfo(); // Refresh display
        Toast.makeText(getContext(), "Successfully topped up ₱" + amount, Toast.LENGTH_SHORT).show();
    }
}