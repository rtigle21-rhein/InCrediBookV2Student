// UserAuthService.java
package com.example.incredibookv2student;

import android.content.Context;
import android.util.Log;

public class UserAuthService {
    private static final String TAG = "UserAuthService";
    private SupabaseUserService supabaseUserService;

    public UserAuthService(Context context) {
        this.supabaseUserService = new SupabaseUserService();
    }

    public void registerUser(String firstName, String lastName, String email,
                             String password, String role, String studentId,
                             SupabaseUserService.RegistrationCallback callback) {
        Log.d(TAG, "Starting registration for user: " + email);

        // First check if email exists
        supabaseUserService.checkEmailExists(email, new SupabaseUserService.CheckExistsCallback() {
            @Override
            public void onResult(boolean exists) {
                if (exists) {
                    Log.e(TAG, "Email already exists: " + email);
                    callback.onError("Email already registered");
                } else {
                    // Check if student ID exists (if provided)
                    if (studentId != null && !studentId.isEmpty()) {
                        supabaseUserService.checkStudentIdExists(studentId, new SupabaseUserService.CheckExistsCallback() {
                            @Override
                            public void onResult(boolean studentIdExists) {
                                if (studentIdExists) {
                                    Log.e(TAG, "Student ID already exists: " + studentId);
                                    callback.onError("Student ID already registered");
                                } else {
                                    proceedWithRegistration(firstName, lastName, email, password, role, studentId, callback);
                                }
                            }

                            @Override
                            public void onError(String error) {
                                Log.e(TAG, "Error checking student ID: " + error);
                                callback.onError("Error checking student ID: " + error);
                            }
                        });
                    } else {
                        proceedWithRegistration(firstName, lastName, email, password, role, studentId, callback);
                    }
                }
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Error checking email: " + error);
                callback.onError("Error checking email: " + error);
            }
        });
    }

    private void proceedWithRegistration(String firstName, String lastName, String email,
                                         String password, String role, String studentId,
                                         SupabaseUserService.RegistrationCallback callback) {
        User newUser = new User(firstName, lastName, email, password, role);
        newUser.setStudentId(studentId);
        supabaseUserService.registerUser(newUser, callback);
    }

    public void registerUserWithNFC(String firstName, String lastName, String email,
                                    String password, String role, String studentId, String nfcUid,
                                    SupabaseUserService.RegistrationCallback callback) {
        Log.d(TAG, "Starting NFC registration for user: " + email + " with NFC: " + nfcUid);

        // First check if NFC UID exists
        supabaseUserService.checkNfcTagIdExists(nfcUid, new SupabaseUserService.CheckExistsCallback() {
            @Override
            public void onResult(boolean nfcExists) {
                if (nfcExists) {
                    Log.e(TAG, "NFC Tag ID already exists: " + nfcUid);
                    callback.onError("NFC card already registered to another user");
                    return;
                }

                // Check if email exists
                supabaseUserService.checkEmailExists(email, new SupabaseUserService.CheckExistsCallback() {
                    @Override
                    public void onResult(boolean emailExists) {
                        if (emailExists) {
                            Log.e(TAG, "Email already exists: " + email);
                            callback.onError("Email already registered");
                            return;
                        }

                        // Check student ID if provided
                        if (studentId != null && !studentId.isEmpty()) {
                            supabaseUserService.checkStudentIdExists(studentId, new SupabaseUserService.CheckExistsCallback() {
                                @Override
                                public void onResult(boolean studentIdExists) {
                                    if (studentIdExists) {
                                        Log.e(TAG, "Student ID already exists: " + studentId);
                                        callback.onError("Student ID already registered");
                                    } else {
                                        proceedWithNfcRegistration(firstName, lastName, email, password, role, studentId, nfcUid, callback);
                                    }
                                }

                                @Override
                                public void onError(String error) {
                                    Log.e(TAG, "Error checking student ID: " + error);
                                    callback.onError("Error checking student ID: " + error);
                                }
                            });
                        } else {
                            proceedWithNfcRegistration(firstName, lastName, email, password, role, studentId, nfcUid, callback);
                        }
                    }

                    @Override
                    public void onError(String error) {
                        Log.e(TAG, "Error checking email: " + error);
                        callback.onError("Error checking email: " + error);
                    }
                });
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Error checking NFC Tag ID: " + error);
                callback.onError("Error checking NFC card: " + error);
            }
        });
    }

    private void proceedWithNfcRegistration(String firstName, String lastName, String email,
                                            String password, String role, String studentId, String nfcUid,
                                            SupabaseUserService.RegistrationCallback callback) {
        User newUser = new User(firstName, lastName, email, password, role);
        newUser.setStudentId(studentId);
        newUser.setNfcTagId(nfcUid);
        supabaseUserService.registerUserWithNFC(newUser, callback);
    }

    public void loginUser(String email, String password, SupabaseUserService.LoginCallback callback) {
        Log.d(TAG, "Attempting login for user: " + email);
        supabaseUserService.loginUser(email, password, callback);
    }

    public void loginUserWithNFC(String nfcTagId, SupabaseUserService.NFCLoginCallback callback) {
        Log.d(TAG, "Attempting NFC login for user with Tag ID: " + nfcTagId);
        supabaseUserService.loginUserWithNFC(nfcTagId, callback);
    }

    public void checkEmailExists(String email, SupabaseUserService.CheckExistsCallback callback) {
        Log.d(TAG, "Checking if email exists: " + email);
        supabaseUserService.checkEmailExists(email, callback);
    }

    public void checkStudentIdExists(String studentId, SupabaseUserService.CheckExistsCallback callback) {
        Log.d(TAG, "Checking if student ID exists: " + studentId);
        supabaseUserService.checkStudentIdExists(studentId, callback);
    }

    public void checkNfcTagIdExists(String nfcTagId, SupabaseUserService.CheckExistsCallback callback) {
        Log.d(TAG, "Checking if NFC Tag ID exists: " + nfcTagId);
        supabaseUserService.checkNfcTagIdExists(nfcTagId, callback);
    }
}