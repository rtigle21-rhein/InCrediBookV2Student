// UserNFCRegisterActivity.java
package com.example.incredibookv2student;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputEditText;
import java.util.regex.Pattern;

public class UserNFCRegisterActivity extends Activity {

    private static final String TAG = "UserNFCRegisterActivity";

    private TextInputEditText editTextFirstName, editTextLastName, editTextEmail,
            editTextPassword, editTextConfirmPassword, editTextStudentId;
    private Button buttonRegister;
    private TextView textViewStatus;
    private TextView textViewLogin;

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private IntentFilter[] intentFiltersArray;
    private String[][] techListsArray;

    private UserAuthService userAuthService;
    private String currentNfcTagId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_nfc_register);

        initializeViews();
        setupNFC();
        setupClickListeners();

        userAuthService = new UserAuthService(this);
        updateRegisterButtonState();
    }

    private void initializeViews() {
        editTextFirstName = findViewById(R.id.editTextFirstName);
        editTextLastName = findViewById(R.id.editTextLastName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        editTextStudentId = findViewById(R.id.editTextStudentId);
        buttonRegister = findViewById(R.id.buttonRegister);
        textViewStatus = findViewById(R.id.textViewStatus);
        textViewLogin = findViewById(R.id.textViewLogin);
    }

    private void setupClickListeners() {
        buttonRegister.setOnClickListener(v -> handleRegistration());
        textViewLogin.setOnClickListener(v -> switchToUserLogin());
    }

    private void setupNFC() {
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC is not available on this device.", Toast.LENGTH_LONG).show();
        } else if (!nfcAdapter.isEnabled()) {
            Toast.makeText(this, "Please enable NFC.", Toast.LENGTH_LONG).show();
        }

        Intent intent = new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE);

        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        intentFiltersArray = new IntentFilter[]{tagDetected};
        techListsArray = new String[][]{new String[]{android.nfc.tech.Ndef.class.getName()}};
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        String action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action) ||
                NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action) ||
                NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)) {
            Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            if (tag != null) {
                currentNfcTagId = bytesToHex(tag.getId());
                textViewStatus.setText("NFC Tag Scanned: " + currentNfcTagId);
                updateRegisterButtonState();
            }
        }
    }

    private void handleRegistration() {
        if (!isFormValid()) {
            Toast.makeText(this, "Please fix the errors and scan an NFC tag.", Toast.LENGTH_LONG).show();
            return;
        }

        final String firstName = editTextFirstName.getText().toString().trim();
        final String lastName = editTextLastName.getText().toString().trim();
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPassword.getText().toString();
        final String studentId = editTextStudentId.getText().toString().trim();
        final String nfcTagId = currentNfcTagId;
        final String role = "student";

        buttonRegister.setEnabled(false);
        buttonRegister.setAlpha(0.5f);
        textViewStatus.setText("Checking availability...");

        userAuthService.registerUserWithNFC(firstName, lastName, email, password, role, studentId, nfcTagId,
                new SupabaseUserService.RegistrationCallback() {
                    @Override
                    public void onResult(boolean success) {
                        runOnUiThread(() -> {
                            buttonRegister.setEnabled(true);
                            buttonRegister.setAlpha(1.0f);

                            if (success) {
                                Toast.makeText(UserNFCRegisterActivity.this,
                                        "User registered with NFC successfully! Please log in.", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(UserNFCRegisterActivity.this, UserLoginActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                textViewStatus.setText("Registration failed.");
                            }
                        });
                    }

                    @Override
                    public void onError(String error) {
                        runOnUiThread(() -> {
                            buttonRegister.setEnabled(true);
                            buttonRegister.setAlpha(1.0f);
                            textViewStatus.setText("Registration failed.");

                            Toast.makeText(UserNFCRegisterActivity.this,
                                    "Registration failed: " + error, Toast.LENGTH_LONG).show();
                        });
                    }
                });
    }

    private boolean isFormValid() {
        boolean isFormFilled = !editTextFirstName.getText().toString().trim().isEmpty() &&
                !editTextLastName.getText().toString().trim().isEmpty() &&
                !editTextEmail.getText().toString().trim().isEmpty() &&
                !editTextPassword.getText().toString().isEmpty() &&
                !editTextConfirmPassword.getText().toString().isEmpty();

        boolean passwordsMatch = editTextPassword.getText().toString().equals(editTextConfirmPassword.getText().toString());
        boolean hasNfcTagId = currentNfcTagId != null && !currentNfcTagId.isEmpty();
        boolean isEmailValid = isEmailValid(editTextEmail.getText().toString().trim());

        if (!isFormFilled) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!passwordsMatch) {
            Toast.makeText(this, "Passwords must match", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!isEmailValid) {
            Toast.makeText(this, "Invalid email format", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!hasNfcTagId) {
            textViewStatus.setText("Please scan your NFC card to register.");
            buttonRegister.setEnabled(false);
            buttonRegister.setAlpha(0.5f);
            return false;
        }

        return true;
    }

    private boolean isEmailValid(String email) {
        return Pattern.compile("^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$").matcher(email).matches();
    }

    private void updateRegisterButtonState() {
        boolean isFormValid = isFormValid();
        buttonRegister.setEnabled(isFormValid);
        buttonRegister.setAlpha(isFormValid ? 1.0f : 0.5f);
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    private void switchToUserLogin() {
        Intent intent = new Intent(this, UserLoginActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (nfcAdapter != null) {
            nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFiltersArray, techListsArray);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }
}