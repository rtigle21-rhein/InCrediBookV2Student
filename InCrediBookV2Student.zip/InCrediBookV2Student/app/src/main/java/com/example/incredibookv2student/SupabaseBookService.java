package com.example.incredibookv2student;

import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

public class SupabaseBookService {
    private static final String TAG = "SupabaseBookService";
    private static final String SUPABASE_URL = "https://qwbmmetkxaluxwpinlee.supabase.co";
    private static final String API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF3Ym1tZXRreGFsdXh3cGlubGVlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0NDk4NDcsImV4cCI6MjA3OTAyNTg0N30.DRQuRm2GoU-UEO17P4FFdBudlenraLatfT6uAuBQk70";

    private OkHttpClient client = new OkHttpClient();
    private Gson gson = new Gson();

    public void getRecentBooks(BookService.BooksCallback callback) {
        String url = SUPABASE_URL + "/rest/v1/books?select=*&order=created_at.desc&limit=10";

        Request request = new Request.Builder()
                .url(url)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", "Bearer " + API_KEY)
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to fetch books: " + e.getMessage());
                callback.onError("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    Log.d(TAG, "Books response: " + responseBody);

                    try {
                        Type bookListType = new TypeToken<List<Book>>(){}.getType();
                        List<Book> books = gson.fromJson(responseBody, bookListType);
                        callback.onResult(books);
                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing books: " + e.getMessage());
                        callback.onError("Failed to parse books data");
                    }
                } else {
                    Log.e(TAG, "Failed to fetch books: " + response.code());
                    callback.onError("Server error: " + response.code());
                }
            }
        });
    }

    public void getAllBooks(BookService.BooksCallback callback) {
        String url = SUPABASE_URL + "/rest/v1/books?select=*";

        Request request = new Request.Builder()
                .url(url)
                .addHeader("apikey", API_KEY)
                .addHeader("Authorization", "Bearer " + API_KEY)
                .addHeader("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to fetch all books: " + e.getMessage());
                callback.onError("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();
                    Log.d(TAG, "All books response: " + responseBody);

                    try {
                        Type bookListType = new TypeToken<List<Book>>(){}.getType();
                        List<Book> books = gson.fromJson(responseBody, bookListType);
                        callback.onResult(books);
                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing all books: " + e.getMessage());
                        callback.onError("Failed to parse books data");
                    }
                } else {
                    Log.e(TAG, "Failed to fetch all books: " + response.code());
                    callback.onError("Server error: " + response.code());
                }
            }
        });
    }
}