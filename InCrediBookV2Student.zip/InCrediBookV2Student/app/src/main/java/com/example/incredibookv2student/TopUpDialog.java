package com.example.incredibookv2student;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import com.google.android.material.textfield.TextInputEditText;

public class TopUpDialog extends DialogFragment {

    private RadioGroup radioGroupAmounts;
    private TextInputEditText editTextCustomAmount;
    private Button buttonConfirm;
    private TopUpListener topUpListener;

    public interface TopUpListener {
        void onTopUp(double amount);
    }

    public void setTopUpListener(TopUpListener listener) {
        this.topUpListener = listener;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_top_up, container, false);

        initializeViews(view);
        setupClickListeners();

        return view;
    }

    private void initializeViews(View view) {
        radioGroupAmounts = view.findViewById(R.id.radioGroupAmounts);
        editTextCustomAmount = view.findViewById(R.id.editTextCustomAmount);
        buttonConfirm = view.findViewById(R.id.buttonConfirm);
    }

    private void setupClickListeners() {
        radioGroupAmounts.setOnCheckedChangeListener((group, checkedId) -> {
            editTextCustomAmount.setText("");
        });

        editTextCustomAmount.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                radioGroupAmounts.clearCheck();
            }
        });

        buttonConfirm.setOnClickListener(v -> processTopUp());
    }

    private void processTopUp() {
        double amount = getSelectedAmount();

        if (amount <= 0) {
            Toast.makeText(getContext(), "Please select or enter a valid amount", Toast.LENGTH_SHORT).show();
            return;
        }

        if (amount < 50) {
            Toast.makeText(getContext(), "Minimum top-up amount is ₱50", Toast.LENGTH_SHORT).show();
            return;
        }

        if (topUpListener != null) {
            topUpListener.onTopUp(amount);
        }

        dismiss();
    }

    private double getSelectedAmount() {
        // Check custom amount first
        String customAmount = editTextCustomAmount.getText().toString().trim();
        if (!customAmount.isEmpty()) {
            try {
                return Double.parseDouble(customAmount);
            } catch (NumberFormatException e) {
                return 0;
            }
        }

        // Check radio buttons
        int selectedId = radioGroupAmounts.getCheckedRadioButtonId();
        if (selectedId == R.id.radio50) return 50;
        if (selectedId == R.id.radio100) return 100;
        if (selectedId == R.id.radio200) return 200;
        if (selectedId == R.id.radio500) return 500;

        return 0;
    }
}