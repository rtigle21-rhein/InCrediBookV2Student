package com.example.incredibookv2student;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;
import java.util.ArrayList;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private List<Book> books;
    private OnBookClickListener listener;

    public interface OnBookClickListener {
        void onBookClick(Book book);
        void onBookLongClick(Book book);
    }

    public BookAdapter(List<Book> books, OnBookClickListener listener) {
        this.books = books != null ? books : new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public BookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.item_book_grid, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookViewHolder holder, int position) {
        Book book = books.get(position);

        if (holder.textTitle != null) {
            holder.textTitle.setText(book.getTitle());
        }
        if (holder.textAuthor != null) {
            holder.textAuthor.setText(book.getAuthor());
        }
        if (holder.textAvailability != null) {
            String availability = book.getAvailableCopies() > 0 ?
                    "Available (" + book.getAvailableCopies() + ")" : "Out of Stock";
            holder.textAvailability.setText(availability);

            // Set text color based on availability
            try {
                int colorRes = book.getAvailableCopies() > 0 ?
                        holder.itemView.getContext().getResources().getIdentifier("color/holo_green_dark", null, holder.itemView.getContext().getPackageName()) :
                        holder.itemView.getContext().getResources().getIdentifier("color/holo_red_dark", null, holder.itemView.getContext().getPackageName());

                if (colorRes != 0) {
                    holder.textAvailability.setTextColor(holder.itemView.getContext().getResources().getColor(colorRes, null));
                }
            } catch (Exception e) {
                // Ignore if color resource not found
            }
        }

        // --- ENHANCED IMAGE LOADING: HANDLES BOTH BASE64 AND URLS ---
        if (holder.ivCover != null) {
            String coverData = book.getCoverImage();

            if (coverData != null && !coverData.isEmpty()) {
                // Direct base64 decoding - like the working code
                try {
                    byte[] decodedBytes = Base64.decode(coverData, Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                    holder.ivCover.setImageBitmap(bitmap);
                } catch (Exception e) {
                    setPlaceholderImage(holder.ivCover);
                }
            } else {
                setPlaceholderImage(holder.ivCover);
            }
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onBookClick(book);
            }
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    // Method to load base64 images
    private void loadBase64Image(ImageView imageView, String base64Data) {
        try {
            // Extract the base64 part after "base64,"
            String base64Image = base64Data.split(",")[1];

            // Decode base64 string to byte array
            byte[] decodedBytes = Base64.decode(base64Image, Base64.DEFAULT);

            // Convert byte array to bitmap
            Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);

            // Set the bitmap to ImageView
            imageView.setImageBitmap(bitmap);

        } catch (Exception e) {
            e.printStackTrace();
            // If base64 decoding fails, fall back to placeholder
            setPlaceholderImage(imageView);
        }
    }

    // Method to load image URLs using Glide
    private void loadImageUrl(ImageView imageView, String imageUrl) {
        try {
            int placeholderId = imageView.getContext().getResources()
                    .getIdentifier("ic_book_cover_placeholder", "drawable", imageView.getContext().getPackageName());

            Glide.with(imageView.getContext())
                    .load(imageUrl)
                    .placeholder(placeholderId != 0 ? placeholderId : android.R.drawable.ic_menu_gallery)
                    .error(placeholderId != 0 ? placeholderId : android.R.drawable.ic_menu_gallery)
                    .into(imageView);
        } catch (Exception e) {
            e.printStackTrace();
            setPlaceholderImage(imageView);
        }
    }

    // Method to set placeholder image
    private void setPlaceholderImage(ImageView imageView) {
        try {
            int placeholderId = imageView.getContext().getResources()
                    .getIdentifier("ic_book_cover_placeholder", "drawable", imageView.getContext().getPackageName());

            if (placeholderId != 0) {
                imageView.setImageResource(placeholderId);
            } else {
                imageView.setImageResource(android.R.drawable.ic_menu_gallery);
            }
        } catch (Exception e) {
            imageView.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }

    public static class BookViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCover;
        TextView textTitle, textAuthor, textAvailability;

        public BookViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCover = itemView.findViewById(R.id.ivCover);
            textTitle = itemView.findViewById(R.id.textTitle);
            textAuthor = itemView.findViewById(R.id.textAuthor);
            textAvailability = itemView.findViewById(R.id.textAvailability);
        }
    }

    // Update book list method
    public void updateBooks(List<Book> newBooks) {
        this.books = newBooks != null ? newBooks : new ArrayList<>();
        notifyDataSetChanged();
    }
}