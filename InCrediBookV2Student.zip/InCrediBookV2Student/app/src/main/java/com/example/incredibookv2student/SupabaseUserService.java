// SupabaseUserService.java
package com.example.incredibookv2student;

import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import okhttp3.*;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.concurrent.TimeUnit;

public class SupabaseUserService {
    private static final String TAG = "SupabaseUserService";
    private static final String SUPABASE_URL = "https://qwbmmetkxaluxwpinlee.supabase.co/rest/v1/";
    private static final String SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF3Ym1tZXRreGFsdXh3cGlubGVlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0NDk4NDcsImV4cCI6MjA3OTAyNTg0N30.DRQuRm2GoU-UEO17P4FFdBudlenraLatfT6uAuBQk70";

    private OkHttpClient client;
    private Gson gson;

    public SupabaseUserService() {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
        this.gson = new Gson();
    }

    // Interfaces
    public interface RegistrationCallback {
        void onResult(boolean success);
        void onError(String error);
    }

    public interface LoginCallback {
        void onResult(User user);
        void onError(String error);
    }

    public interface NFCLoginCallback {
        void onResult(User user);
        void onError(String error);
    }

    public interface CheckExistsCallback {
        void onResult(boolean exists);
        void onError(String error);
    }

    // Method 1: Register user
    public void registerUser(User user, RegistrationCallback callback) {
        Log.d(TAG, "Registering user: " + user.getEmail());

        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("first_name", user.getFirstName());
            requestBody.put("last_name", user.getLastName());
            requestBody.put("email", user.getEmail());
            requestBody.put("password_hash", user.getPasswordHash());
            requestBody.put("role", user.getRole());

            if (user.getStudentId() != null) {
                requestBody.put("student_id", user.getStudentId());
            }
            if (user.getMiddleName() != null) {
                requestBody.put("middle_name", user.getMiddleName());
            }
            if (user.getPhoneNumber() != null) {
                requestBody.put("phone_number", user.getPhoneNumber());
            }
            if (user.getSchool() != null) {
                requestBody.put("school", user.getSchool());
            }
            if (user.getAge() != null) {
                requestBody.put("age", user.getAge());
            }
            if (user.getGender() != null) {
                requestBody.put("gender", user.getGender());
            }
            if (user.getAddress() != null) {
                requestBody.put("address", user.getAddress());
            }

            RequestBody body = RequestBody.create(
                    requestBody.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "users")
                    .post(body)
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Registration error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d(TAG, "Registration successful for user: " + user.getEmail());
                        callback.onResult(true);
                    } else {
                        String errorMessage = "Registration failed";
                        try {
                            String responseBody = response.body().string();
                            Log.e(TAG, "Registration failed response: " + responseBody);

                            if (responseBody.contains("duplicate key") && responseBody.contains("email")) {
                                errorMessage = "Email already registered";
                            } else if (responseBody.contains("duplicate key") && responseBody.contains("student_id")) {
                                errorMessage = "Student ID already registered";
                            } else if (response.code() == 400) {
                                errorMessage = "Invalid request data";
                            } else if (response.code() == 500) {
                                errorMessage = "Server error during registration";
                            }
                        } catch (Exception e) {
                            errorMessage = "Registration failed with code: " + response.code();
                        }
                        callback.onError(errorMessage);
                    }
                }
            });

        } catch (JSONException e) {
            Log.e(TAG, "JSON error in registration: " + e.getMessage());
            callback.onError("JSON error: " + e.getMessage());
        }
    }

    // Method 2: Register user with NFC
    public void registerUserWithNFC(User user, RegistrationCallback callback) {
        Log.d(TAG, "Registering user with NFC: " + user.getEmail());

        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("first_name", user.getFirstName());
            requestBody.put("last_name", user.getLastName());
            requestBody.put("email", user.getEmail());
            requestBody.put("password_hash", user.getPasswordHash());
            requestBody.put("role", user.getRole());
            requestBody.put("nfc_tag_id", user.getNfcTagId());

            if (user.getStudentId() != null) {
                requestBody.put("student_id", user.getStudentId());
            }
            if (user.getMiddleName() != null) {
                requestBody.put("middle_name", user.getMiddleName());
            }

            RequestBody body = RequestBody.create(
                    requestBody.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "users")
                    .post(body)
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "NFC registration error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d(TAG, "NFC registration successful for user: " + user.getEmail());
                        callback.onResult(true);
                    } else {
                        String errorMessage = "NFC registration failed";
                        try {
                            String responseBody = response.body().string();
                            Log.e(TAG, "NFC registration failed response: " + responseBody);

                            if (responseBody.contains("duplicate key") && responseBody.contains("email")) {
                                errorMessage = "Email already registered";
                            } else if (responseBody.contains("duplicate key") && responseBody.contains("nfc_tag_id")) {
                                errorMessage = "NFC card already registered";
                            } else if (responseBody.contains("duplicate key") && responseBody.contains("student_id")) {
                                errorMessage = "Student ID already registered";
                            }
                        } catch (Exception e) {
                            errorMessage = "Registration failed with code: " + response.code();
                        }
                        callback.onError(errorMessage);
                    }
                }
            });

        } catch (JSONException e) {
            Log.e(TAG, "JSON error in NFC registration: " + e.getMessage());
            callback.onError("JSON error: " + e.getMessage());
        }
    }

    // Method 3: Manual User Login
    public void loginUser(String email, String password, LoginCallback callback) {
        Log.d(TAG, "Attempting manual login for user: " + email);

        try {
            String encodedEmail = URLEncoder.encode(email, "UTF-8");
            String url = SUPABASE_URL + "users?email=eq." + encodedEmail + "&select=*";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Login network error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            Log.d(TAG, "Login response: " + responseBody);

                            if (responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty()) {
                                JsonArray jsonArray = JsonParser.parseString(responseBody).getAsJsonArray();
                                if (jsonArray.size() > 0) {
                                    User user = gson.fromJson(jsonArray.get(0), User.class);

                                    // Verify password
                                    if (user.getPasswordHash() != null && user.getPasswordHash().equals(password)) {
                                        callback.onResult(user);
                                    } else {
                                        callback.onResult(null);
                                    }
                                    return;
                                }
                            }
                            callback.onResult(null);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing login response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "Login failed: " + response.code() + " - " + errorBody);
                        callback.onError("Login failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in login: " + e.getMessage());
            callback.onError("Login error: " + e.getMessage());
        }
    }

    // Method 4: NFC Login
    public void loginUserWithNFC(String nfcTagId, NFCLoginCallback callback) {
        Log.d(TAG, "Attempting NFC login with Tag ID: " + nfcTagId);

        try {
            String encodedNfcTagId = URLEncoder.encode(nfcTagId, "UTF-8");
            String url = SUPABASE_URL + "users?nfc_tag_id=eq." + encodedNfcTagId + "&select=*";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "NFC login network error: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            Log.d(TAG, "NFC login response: " + responseBody);

                            if (responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty()) {
                                JsonArray jsonArray = JsonParser.parseString(responseBody).getAsJsonArray();
                                if (jsonArray.size() > 0) {
                                    User user = gson.fromJson(jsonArray.get(0), User.class);
                                    callback.onResult(user);
                                    return;
                                }
                            }
                            callback.onResult(null);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing NFC login response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "NFC login failed: " + response.code() + " - " + errorBody);
                        callback.onError("Login failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in NFC login: " + e.getMessage());
            callback.onError("Login error: " + e.getMessage());
        }
    }

    // Method 5: Check if Email exists
    public void checkEmailExists(String email, CheckExistsCallback callback) {
        Log.d(TAG, "Checking if email exists: " + email);

        try {
            String encodedEmail = URLEncoder.encode(email, "UTF-8");
            String url = SUPABASE_URL + "users?email=eq." + encodedEmail + "&select=email";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Error checking email: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            boolean exists = responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty();
                            callback.onResult(exists);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing email check response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "Email check failed: " + response.code() + " - " + errorBody);
                        callback.onError("Check failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in email check: " + e.getMessage());
            callback.onError("Check error: " + e.getMessage());
        }
    }

    // Method 6: Check if Student ID exists
    public void checkStudentIdExists(String studentId, CheckExistsCallback callback) {
        Log.d(TAG, "Checking if student ID exists: " + studentId);

        try {
            String encodedStudentId = URLEncoder.encode(studentId, "UTF-8");
            String url = SUPABASE_URL + "users?student_id=eq." + encodedStudentId + "&select=student_id";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Error checking student ID: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            boolean exists = responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty();
                            callback.onResult(exists);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing student ID check response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "Student ID check failed: " + response.code() + " - " + errorBody);
                        callback.onError("Check failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in student ID check: " + e.getMessage());
            callback.onError("Check error: " + e.getMessage());
        }
    }

    // Method 7: Check if NFC Tag ID exists
    public void checkNfcTagIdExists(String nfcTagId, CheckExistsCallback callback) {
        Log.d(TAG, "Checking if NFC Tag ID exists: " + nfcTagId);

        try {
            String encodedNfcTagId = URLEncoder.encode(nfcTagId, "UTF-8");
            String url = SUPABASE_URL + "users?nfc_tag_id=eq." + encodedNfcTagId + "&select=nfc_tag_id";

            Request request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Error checking NFC Tag ID: " + e.getMessage());
                    callback.onError(e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        try {
                            String responseBody = response.body().string();
                            boolean exists = responseBody != null && !responseBody.equals("[]") && !responseBody.isEmpty();
                            callback.onResult(exists);
                        } catch (Exception e) {
                            Log.e(TAG, "Error parsing NFC Tag ID check response: " + e.getMessage());
                            callback.onError("Error parsing response");
                        }
                    } else {
                        String errorBody = response.body() != null ? response.body().string() : "No error body";
                        Log.e(TAG, "NFC Tag ID check failed: " + response.code() + " - " + errorBody);
                        callback.onError("Check failed: " + response.code());
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in NFC Tag ID check: " + e.getMessage());
            callback.onError("Check error: " + e.getMessage());
        }
    }
}