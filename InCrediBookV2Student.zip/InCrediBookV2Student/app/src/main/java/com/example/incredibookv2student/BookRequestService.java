package com.example.incredibookv2student;

import android.content.SharedPreferences;
import android.util.Log;
import com.google.gson.Gson;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

public class BookRequestService {
    private static final String TAG = "BookRequestService";
    private static final String SUPABASE_URL = "https://qwbmmetkxaluxwpinlee.supabase.co/rest/v1/";
    private static final String SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF3Ym1tZXRreGFsdXh3cGlubGVlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0NDk4NDcsImV4cCI6MjA3OTAyNTg0N30.DRQuRm2GoU-UEO17P4FFdBudlenraLatfT6uAuBQk70";

    private OkHttpClient client;
    private Gson gson;
    private SharedPreferences sharedPreferences;

    public BookRequestService(SharedPreferences sharedPreferences) {
        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
        this.gson = new Gson();
        this.sharedPreferences = sharedPreferences;
    }

    public interface BookRequestCallback {
        void onSuccess(String message);
        void onError(String error);
    }

    public void requestBook(String bookId, BookRequestCallback callback) {
        String userId = sharedPreferences.getString("userId", "");
        double walletBalance = sharedPreferences.getFloat("walletBalance", 0.0f);
        double borrowingFee = 10.0; // Example fee

        if (walletBalance < borrowingFee) {
            callback.onError("Insufficient wallet balance. Please top up your wallet.");
            return;
        }

        // Calculate dates
        Calendar calendar = Calendar.getInstance();
        String borrowDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime());
        calendar.add(Calendar.DAY_OF_YEAR, 14); // 2 weeks borrowing period
        String dueDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime());

        try {
            JSONObject requestBody = new JSONObject();
            requestBody.put("user_id", userId);
            requestBody.put("book_id", bookId);
            requestBody.put("borrow_date", borrowDate);
            requestBody.put("due_date", dueDate);
            requestBody.put("status", "requested");
            requestBody.put("borrowing_fee", borrowingFee);

            RequestBody body = RequestBody.create(
                    requestBody.toString(),
                    MediaType.parse("application/json; charset=utf-8")
            );

            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "borrow_records")
                    .post(body)
                    .addHeader("apikey", SUPABASE_ANON_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_ANON_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, java.io.IOException e) {
                    Log.e(TAG, "Book request error: " + e.getMessage());
                    callback.onError("Network error: " + e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) {
                    if (response.isSuccessful()) {
                        // Deduct from wallet
                        deductFromWallet(borrowingFee);
                        callback.onSuccess("Book requested successfully! Due date: " + dueDate);
                    } else {
                        String errorMessage = "Failed to request book";
                        callback.onError(errorMessage);
                    }
                    response.close();
                }
            });

        } catch (JSONException e) {
            Log.e(TAG, "JSON error in book request: " + e.getMessage());
            callback.onError("JSON error: " + e.getMessage());
        }
    }

    private void deductFromWallet(double amount) {
        double currentBalance = sharedPreferences.getFloat("walletBalance", 0.0f);
        double newBalance = currentBalance - amount;

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat("walletBalance", (float) newBalance);
        editor.apply();
    }
}