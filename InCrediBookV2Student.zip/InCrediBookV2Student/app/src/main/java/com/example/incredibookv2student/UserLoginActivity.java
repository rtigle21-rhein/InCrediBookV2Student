package com.example.incredibookv2student;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UserLoginActivity extends AppCompatActivity {

    private EditText editTextEmail, editTextPassword;
    private Button buttonUserLogin;
    private TextView textViewRegister, textViewNFCLogin;
    private SharedPreferences sharedPreferences;
    private UserAuthService userAuthService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        initializeViews();
        setupClickListeners();

        sharedPreferences = getSharedPreferences("InCrediBookPrefs", MODE_PRIVATE);
        userAuthService = new UserAuthService(this);

        // Check if user is already logged in
        checkExistingLogin();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Check login status when activity resumes
        checkExistingLogin();
    }

    private void initializeViews() {
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonUserLogin = findViewById(R.id.buttonUserLogin);
        textViewRegister = findViewById(R.id.textViewRegister);
        textViewNFCLogin = findViewById(R.id.textViewNFCLogin);
    }

    private void setupClickListeners() {
        buttonUserLogin.setOnClickListener(v -> handleUserLogin());
        textViewRegister.setOnClickListener(v -> switchToUserRegister());
        textViewNFCLogin.setOnClickListener(v -> switchToUserNFCLogin());
    }

    private void checkExistingLogin() {
        boolean isUserLoggedIn = sharedPreferences.getBoolean("isUserLoggedIn", false);

        if (isUserLoggedIn) {
            // User is logged in, redirect to User Dashboard
            Intent intent = new Intent(this, UserDashboardActivity.class);
            startActivity(intent);
            finish();
        }
        // If not logged in, stay on login screen
    }

    private void handleUserLogin() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter Email and Password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Disable button during login attempt
        buttonUserLogin.setEnabled(false);
        buttonUserLogin.setText("Logging In...");

        userAuthService.loginUser(email, password, new SupabaseUserService.LoginCallback() {
            @Override
            public void onResult(User user) {
                runOnUiThread(() -> {
                    buttonUserLogin.setEnabled(true);
                    buttonUserLogin.setText("Login");

                    if (user != null) {
                        Toast.makeText(UserLoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                        saveUserDetails(user);
                        Intent intent = new Intent(UserLoginActivity.this, UserDashboardActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(UserLoginActivity.this, "Invalid Email or Password.", Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    buttonUserLogin.setEnabled(true);
                    buttonUserLogin.setText("Login");

                    Toast.makeText(UserLoginActivity.this,
                            "Login failed: " + error, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void saveUserDetails(User user) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isUserLoggedIn", true);
        editor.putString("userId", user.getId());
        editor.putString("userEmail", user.getEmail());
        editor.putString("userFullName", user.getFullName());
        editor.putString("userRole", user.getRole());
        editor.putString("studentId", user.getStudentId());

        if (user.getNfcTagId() != null && !user.getNfcTagId().isEmpty()) {
            editor.putBoolean("hasNFCRegistered", true);
            editor.putString("nfcTagId", user.getNfcTagId());
        } else {
            editor.putBoolean("hasNFCRegistered", false);
        }

        editor.apply();
    }

    private void switchToUserRegister() {
        Intent intent = new Intent(this, UserRegisterActivity.class);
        startActivity(intent);
        // Don't finish() so user can press back to return to login
    }

    private void switchToUserNFCLogin() {
        Intent intent = new Intent(this, UserNFCLoginActivity.class);
        startActivity(intent);
        // Don't finish() so user can press back to return to login
    }

    @Override
    public void onBackPressed() {
        // Exit the app when back button is pressed on login screen
        super.onBackPressed();
        finishAffinity();
    }
}