// UserRegisterActivity.java
package com.example.incredibookv2student;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UserRegisterActivity extends AppCompatActivity {

    private EditText editTextFirstName, editTextLastName, editTextEmail,
            editTextPassword, editTextConfirmPassword, editTextStudentId;
    private Button buttonRegister, buttonRegisterWithNFC;
    private TextView textViewLogin;
    private UserAuthService userAuthService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);

        initializeViews();
        setupClickListeners();

        userAuthService = new UserAuthService(this);
    }

    private void initializeViews() {
        editTextFirstName = findViewById(R.id.editTextFirstName);
        editTextLastName = findViewById(R.id.editTextLastName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        editTextStudentId = findViewById(R.id.editTextStudentId);
        buttonRegister = findViewById(R.id.buttonRegister);
        buttonRegisterWithNFC = findViewById(R.id.buttonRegisterWithNFC);
        textViewLogin = findViewById(R.id.textViewLogin);
    }

    private void setupClickListeners() {
        buttonRegister.setOnClickListener(v -> handleUserRegistration());
        buttonRegisterWithNFC.setOnClickListener(v -> switchToNFCUserRegistration());
        textViewLogin.setOnClickListener(v -> switchToUserLogin());
    }

    private void handleUserRegistration() {
        String firstName = editTextFirstName.getText().toString().trim();
        String lastName = editTextLastName.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();
        String studentId = editTextStudentId.getText().toString().trim();

        if (validateInput(firstName, lastName, email, password, confirmPassword)) {
            // Show loading state
            buttonRegister.setEnabled(false);
            buttonRegister.setText("Registering...");

            registerUser(firstName, lastName, email, password, studentId);
        }
    }

    private boolean validateInput(String firstName, String lastName, String email,
                                  String password, String confirmPassword) {
        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() ||
                password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void registerUser(String firstName, String lastName, String email,
                              String password, String studentId) {
        String role = "student"; // Default role

        userAuthService.registerUser(firstName, lastName, email, password, role, studentId,
                new SupabaseUserService.RegistrationCallback() {
                    @Override
                    public void onResult(boolean success) {
                        runOnUiThread(() -> {
                            buttonRegister.setEnabled(true);
                            buttonRegister.setText("Register");

                            if (success) {
                                Toast.makeText(UserRegisterActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(UserRegisterActivity.this, UserLoginActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(UserRegisterActivity.this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    @Override
                    public void onError(String error) {
                        runOnUiThread(() -> {
                            buttonRegister.setEnabled(true);
                            buttonRegister.setText("Register");

                            Toast.makeText(UserRegisterActivity.this,
                                    "Registration failed: " + error, Toast.LENGTH_LONG).show();
                        });
                    }
                });
    }

    private void switchToNFCUserRegistration() {
        Intent intent = new Intent(this, UserNFCRegisterActivity.class);
        startActivity(intent);
        finish();
    }

    private void switchToUserLogin() {
        Intent intent = new Intent(this, UserLoginActivity.class);
        startActivity(intent);
        finish();
    }
}